local lfs = require("lfs")
local curl = require("cURL")
local json = require("json")
local app = require("libs/support") 
local imgPath      = rootDir() .."/img/"
local Debug = rootDir() .."/Debug/*"
local bundleID     = "com.ss.iphone.ugc.Ame"
keepAutoTouchAwake(true);
local ip = checkCountry()
function autoTuongTac(countDay)
    countDay = countDay or 7
    counTimkiem = 0
    counxemBinhLuan = 0
    counrePost = 0
    counxemLive = 0
    function randomcfg(a,b,c)
        r =  random(b,c)
        return (tonumber(a) or 0) + r
    end
    local dataconfig = split(licham365(613), "|")
    local randoocounTimkiem = randomcfg(dataconfig[3] ,1 , 3)
    local randoocounxemBinhLuan = randomcfg(dataconfig[4] ,1 , 3)
    local randoocounrePost =randomcfg(dataconfig[5] ,1 , 3)
    local randoocounxemLive = randomcfg(dataconfig[6] ,1 , 3)
    local TimeEnd1 = math.random(dataconfig[1], dataconfig[2])
    local TimeEnd = TimeEnd1*60
    local Timeauto = os.time()
    local now = os.time()
    local futureTime = now + TimeEnd
    local formattedFuture = os.date("%H:%M:%S", futureTime)
    function getProxyInfo(proxyType,key,tinhthanh)
        -- Mặc định nếu không truyền gì → lấy socks5
        proxyType = proxyType or "socks5"
        -- Gọi API
        local url = "https://proxyxoay.shop/api/get.php?key="..key.."&&nhamang=random&&tinhthanh="..tinhthanh
        local response = unescape_unicode(quickGetString(url))
        -- Kiểm tra dữ liệu
        if not response or response == "" then
            return nil, "Không nhận được phản hồi từ API"
        end
        if not string.find(response, '"status"%s*:%s*100') then
            return nil 
        end
        -- Xác định trường proxy cần lấy
        local proxyKey = proxyType == "http" and "proxyhttp" or "proxysocks5"
        local proxy = string.match(response, '"' .. proxyKey .. '"%s*:%s*"([^"]+)"')
        local message = string.match(response, '"message"%s*:%s*"([^"]+)"')
        local viTri = string.match(response, '"Vi Tri"%s*:%s*"([^"]+)"')
        local expire = string.match(response, '"Token expiration date"%s*:%s*"([^"]+)"')
        if not proxy then
            return nil, "Không tìm thấy proxy loại: " .. proxyKey
        end
        return proxy
    end
    
    function thongbao()
        local diff = os.difftime(os.time(), TimeEnd)
        local minutes = math.floor(diff / 60)
            toast("Chạy tương tác tiktok ngày "..countDay..
            "\nIP: "..ip..
            "\nThời Gian chạy  "..TimeEnd1.." Phút" .. " Tắt lúc " ..formattedFuture..
            "\nTìm kiếm lần " .. counTimkiem .. "/" .. randoocounTimkiem ..
            "\nXem comment lần"..counxemBinhLuan.."/"..randoocounxemBinhLuan..
            "\nGoto LIVE lần "..counxemLive.."/"..randoocounxemLive..
            "\nRepost video lần "..counrePost.."/"..randoocounrePost,3)
    end
    thongbao()

    function reOpenTiktok()
        local orientation = frontMostAppOrientation();
        if orientation ~= bundleID then
            openURL("snssdk1233://feed")
            usleep(15000000) 
        end
    end
    function check_Logout()
        if findimgs({"img/check_secure.png","img/check_loginform.png","img/check_login.png"},2) then
            toast("Logout",5)               
            stop();
        end
    end

    function timkiem()
        check_Logout()
        if counTimkiem < randoocounTimkiem then
            counTimkiem = counTimkiem + 1
            thongbao()
            openURL("snssdk1233://search")
            waitrandom(3,5)
            findimgsandclick({"img/xsearch.png","img/search.png"}, 2)
            waitrandom(3,5)
            findimgsandclick({"img/bt_data_search.png"}, 2)
            waitrandom(3,5)
            tap(169,327)
            waitrandom(3,5)
            local x=random(136,600)
            swipe(x,485,x,150,0.1)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x,485,x,150,0.1)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x,485,x,150,0.1)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x,485,x,150,0.1)
            waitrandom(6,10)
            reOpenTiktok()
            openURL("snssdk1233://inbox")
            usleep(6000000)        
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_open.png","img/bt_save.png"}, 2)
            tap(65, 1280);
        else
            toast("Giới hạn Tìm kiếm"..randoocounTimkiem,2)
        end
    end

    function swipe1()
        touchDown(4, 234.01, 838.37);
        usleep(83463.25);
        touchMove(4, 232.99, 828.19);
        usleep(16623.75);
        touchMove(4, 232.99, 817.00);
        usleep(16761.38);
        touchMove(4, 234.01, 795.60);
        usleep(16636.71);
        touchMove(4, 236.07, 778.30);
        usleep(16872.92);
        touchMove(4, 238.12, 763.04);
        usleep(16440.25);
        touchMove(4, 240.18, 747.75);
        usleep(16710.46);
        touchMove(4, 243.26, 732.48);
        usleep(16602.75);
        touchMove(4, 246.33, 719.25);
        usleep(16778.71);
        touchMove(4, 249.41, 706.02);
        usleep(16556.67);
        touchMove(4, 253.52, 689.72);
        usleep(16803.21);
        touchMove(4, 256.60, 677.50);
        usleep(16494.79);
        touchMove(4, 259.68, 665.29);
        usleep(16993.21);
        touchMove(4, 262.76, 655.11);
        usleep(16557.08);
        touchMove(4, 263.77, 646.95);
        usleep(16488.46);
        touchMove(4, 265.83, 640.84);
        usleep(16770.88);
        touchMove(4, 266.85, 635.75);
        usleep(16729.92);
        touchMove(4, 267.88, 631.68);
        usleep(16615.75);
        touchMove(4, 268.91, 629.65);
        usleep(16565.92);
        touchMove(4, 269.94, 627.61);
        usleep(16837.04);
        touchMove(4, 270.96, 625.58);
        usleep(16526.79);
        touchMove(4, 270.96, 624.56);
        usleep(16547.17);
        touchMove(4, 270.96, 623.54);
        usleep(66769.83);
        touchMove(4, 271.99, 623.54);
        usleep(16651.58);
        touchMove(4, 273.02, 623.54);
        usleep(16712.79);
        touchUp(4, 275.07, 631.68);
    end

    function xemBinhLuan()
        check_Logout()
        if counxemBinhLuan < randoocounxemBinhLuan then
            if findimgs({"img/check_video_running.png"},2) then
                counxemBinhLuan = counxemBinhLuan + 1
                thongbao()
                tap(707, 760,2);
                waitrandom(3,5) 
                swipe1()
                waitrandom(1,2)
                swipe1()            
                waitrandom(1,2)
                swipe1()            
                waitrandom(1,2)
                swipe1()            
                waitrandom(1,2)
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)        
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_open.png","img/bt_save.png"}, 2)
                tap(65, 1280);
            else
                toast("Giới hạn Coment"..randoocounxemBinhLuan,2)
            end
        end
    end

    function clickLike()
    check_Logout()
        if countDay > 6 then
            if findimgs({"img/check_video_running.png"},2) then
                toast("Like video",2)
                tap(707, 670)
            end
        end
    end

    function luotvideo(time)
        local startTime = os.time()
        while 1<2 do
            check_Logout()
            local diff = os.difftime(os.time(), TimeEnd)
            local minutes = math.floor(diff / 60)
            toast("Chạy tương tác tiktok ngày "..countDay..
            "\nIP: "..ip..
            "\nThời Gian chạy  "..TimeEnd1.." Phút" .. " Tắt lúc " ..formattedFuture..
            "\nTìm kiếm lần " .. counTimkiem .. "/" .. randoocounTimkiem ..
            "\nXem comment lần"..counxemBinhLuan.."/"..randoocounxemBinhLuan..
            "\nGoto LIVE lần "..counxemLive.."/"..randoocounxemLive..
            "\nRepost video lần "..counrePost.."/"..randoocounrePost..
            "\nLướt video "..os.difftime(os.time(), startTime).."/"..time.." Giây",3)
            local x=random(136,600)
            --swipe(x,485,x,150,0.1)
            tap(65, 1280);
            waitrandom(8,15)
            if os.difftime(os.time(), startTime) > time then
                break
            end
        end
    end

    function xemLive()
            check_Logout()
        if counxemLive < randoocounxemLive then
            if findimgs({"img/check_video_running.png"},2) then
                counxemLive = counxemLive + 1
                thongbao()
                tap(72, 83);
                usleep(math.random(15000000, 20000000))
                if countDay < 7 then
                    swipe(426,496,475,165,0.1)
                    usleep(math.random(30000000, 60000000))
                end
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)  
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_open.png","img/bt_save.png"}, 2)
                tap(65, 1280);
            end   
        else
            toast("Giới hạn Goto LIVE"..randoocounxemLive,2)
        end
    end

    function rePost()
        if counrePost < randoocounrePost then
            check_Logout()
            if findimgs({"img/check_video_running.png"},2) then
                counrePost = counrePost + 1
                thongbao()
                tap(697, 1029);
                usleep(2300167.83);
                tap(74, 1025);
                usleep(3102982.83);
                tap(404, 1229);
                usleep(5102982.83);
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)        
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_open.png","img/bt_save.png"}, 2)
                tap(65, 1280);
            end   
        else
            toast("Giới hạn Goto LIVE "..randoocounrePost,2)
        end
    end
    local r_tuongtac = math.random(2, 4)
    if countDay < 7 then
        r_tuongtac = math.random(4, 5)
    end
    
    while 1<2 do
        local status = checkNetworkStatus()
        local mac = getMacAddress()
        if status == "online" then
            toast("Online", 4)
            reOpenTiktok()
            check_Logout()
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_open.png","img/bt_save.png"}, 2)          
            if findimgs({"img/check_video_running.png"},2) then
                swipe(426,496,475,165,0.1)
            else
                local orientation = frontMostAppOrientation();
                if orientation ~= bundleID then
                    appRun(bundleID)
                    usleep(15000000) 
                end
                openURL("snssdk1233://inbox")
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_open.png","img/bt_save.png"}, 2)
                usleep(500000)
                tap(65, 1280);
                usleep(500000)
                tap(65, 1280);
            end
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_open.png","img/bt_save.png"}, 2)
            luotvideo(math.random(60, 120))         
            local randoo = math.random(1, 6)
            toast("Lắc xí ngầu "..randoo,2)
            if randoo == 1 then
                usleep(2000000)
                toast("Bỏ Lượt",2)
            elseif randoo == 2 then
                clickLike()
            elseif randoo == 3 then
                xemBinhLuan()
            elseif randoo == 4 then
                clickLike()
                xemBinhLuan()
                xemLive()
            elseif randoo == 5 then
                rePost()
            elseif randoo == 6 then
                timkiem()
            end

        elseif status == "nowifi" then
            toast("❌ Không có IP (chưa kết nối mạng LAN/WiFi)", 4)
        elseif status == "no_internet" then
            toast("❌ no_internet", 4)
            appKill(bundleID);
             waitrandom(2,3)
            local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..mac.."|"))
            if string.find(stringProxy, "Remove proxy success") then toast("Remove proxy success",5) wait(3)end
            local proxy, err =getProxyInfo("proxysocks5",licham365(674),3)
                if proxy then
                    local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..mac.."|"..proxy..":socks"))
                    if string.find(stringProxy, "Update proxy success") then toast(proxy,5) reOpenTiktok() end
                end 
        else
            toast("❓ Trạng thái mạng không xác định", 3)
        end



            usleep(math.random(2000000, 3000000))            
        if os.difftime(os.time(), Timeauto) > TimeEnd then
                break
        end
    end   
end
autoTuongTac(6)
closeAllApp()
execute("rm -r "..Debug)
