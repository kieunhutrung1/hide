local lfs = require("lfs")
local curl = require("cURL")
local json = require("json")
local app = require("libs/support") 
local imgPath      = rootDir() .."/img/"
local Debug = rootDir() .."/Debug/*"
local bundleID     = "com.ss.iphone.ugc.Ame"
keepAutoTouchAwake(true);
appKill(bundleID);
keyPress(KEY_TYPE.HOME_BUTTON)
usleep(2000000)
keyPress(KEY_TYPE.HOME_BUTTON)
local ip = checkCountry()
function autoTuongTac(countDay)
    countDay = countDay or 7
    counTimkiem = 0
    counxemBinhLuan = 0
    counrePost = 0
    counxemLive = 0
    function randomcfg(a,b,c)
        r =  random(b,c)
        return (tonumber(a) or 0) + r
    end
    local dataconfig = split(licham365(613), "|")
    local randoocounTimkiem = randomcfg(dataconfig[3] ,1 , 3)
    local randoocounxemBinhLuan = randomcfg(dataconfig[4] ,1 , 3)
    local randoocounrePost =randomcfg(dataconfig[5] ,1 , 3)
    local randoocounxemLive = randomcfg(dataconfig[6] ,1 , 3)
    local TimeEnd1 = math.random(dataconfig[1], dataconfig[2])
    local TimeEnd = TimeEnd1*60
    local Timeauto = os.time()
    local now = os.time()
    local futureTime = now + TimeEnd
    local formattedFuture = os.date("%H:%M:%S", futureTime)
    function getProxyInfo(proxyType,key,tinhthanh)
        -- Mặc định nếu không truyền gì → lấy socks5
        proxyType = proxyType or "socks5"
        -- Gọi API
        local url = "https://proxyxoay.shop/api/get.php?key="..key.."&&nhamang=random&&tinhthanh="..tinhthanh
        local response = unescape_unicode(quickGetString(url))
        -- Kiểm tra dữ liệu
        if not response or response == "" then
            return nil, "Không nhận được phản hồi từ API"
        end
        if not string.find(response, '"status"%s*:%s*100') then
            return nil 
        end
        -- Xác định trường proxy cần lấy
        local proxyKey = proxyType == "http" and "proxyhttp" or "proxysocks5"
        local proxy = string.match(response, '"' .. proxyKey .. '"%s*:%s*"([^"]+)"')
        local message = string.match(response, '"message"%s*:%s*"([^"]+)"')
        local viTri = string.match(response, '"Vi Tri"%s*:%s*"([^"]+)"')
        local expire = string.match(response, '"Token expiration date"%s*:%s*"([^"]+)"')
        if not proxy then
            return nil, "Không tìm thấy proxy loại: " .. proxyKey
        end
        return proxy
    end
    
    function thongbao()
        local diff = os.difftime(os.time(), TimeEnd)
        local minutes = math.floor(diff / 60)
            toast("Chạy tương tác tiktok ngày "..countDay..
            "\nIP: "..ip..
            "\nThời Gian chạy  "..TimeEnd1.." Phút" .. " Tắt lúc " ..formattedFuture..
            "\nTìm kiếm lần " .. counTimkiem .. "/" .. randoocounTimkiem ..
            "\nXem comment lần"..counxemBinhLuan.."/"..randoocounxemBinhLuan..
            "\nGoto LIVE lần "..counxemLive.."/"..randoocounxemLive..
            "\nRepost video lần "..counrePost.."/"..randoocounrePost,3)
    end
    thongbao()

    function reOpenTiktok()
        local orientation = frontMostAppOrientation();
        if orientation ~= bundleID then
            openURL("snssdk1233://feed")
            usleep(15000000) 
        end
    end
    function check_Logout()
        if findimgs({"img/check_secure.png","img/check_loginform.png","img/check_login.png"},2) then
            toast("Logout",5)               
            stop();
        end
    end

    function timkiem()
        check_Logout()
        if counTimkiem < randoocounTimkiem then
            counTimkiem = counTimkiem + 1
            thongbao()
            openURL("snssdk1233://search")
            waitrandom(3,5)
            findimgsandclick({"img/xsearch.png","img/search.png"}, 2)
            waitrandom(3,5)
            findimgsandclick({"img/bt_data_search.png"}, 2)
            waitrandom(3,5)
            tap(169,327)
            waitrandom(3,5)
            local x=random(136,600)
            swipe(x, 621, "up", 0.2,150)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x, 621, "up", 0.2,150)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x, 621, "up", 0.2,150)
            waitrandom(6,10)
            local x=random(136,600)
            swipe(x, 621, "up", 0.2,150)
            waitrandom(6,10)
            reOpenTiktok()
            openURL("snssdk1233://inbox")
            usleep(6000000)        
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
            tap(65, 1280);
        else
            toast("Giới hạn Tìm kiếm"..randoocounTimkiem,2)
        end
    end

    

    function xemBinhLuan()
        check_Logout()
        if counxemBinhLuan < randoocounxemBinhLuan then
            if findimgs({"img/check_video_running.png"},2) then
                counxemBinhLuan = counxemBinhLuan + 1
                thongbao()
                tap(707, 760,2);
                waitrandom(3,5) 
                swipe(365, 621, "up", 0.2,150)
                waitrandom(1,2)
                swipe(365, 621, "up", 0.2,150)            
                waitrandom(1,2)
                swipe(365, 621, "up", 0.2,150)            
                waitrandom(1,2)
                swipe(365, 621, "up", 0.2,150)            
                waitrandom(1,2)
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)        
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
                tap(65, 1280);
            else
                toast("Giới hạn Coment"..randoocounxemBinhLuan,2)
            end
        end
    end

    function clickLike()
    check_Logout()
        if countDay > 6 then
            if findimgs({"img/check_video_running.png"},2) then
                toast("Like video",2)
                tap(707, 670)
            end
        end
    end

    function luotvideo(time)
        local startTime = os.time()
        while 1<2 do
            check_Logout()
            local diff = os.difftime(os.time(), TimeEnd)
            local minutes = math.floor(diff / 60)
            toast("Chạy tương tác tiktok ngày "..countDay..
            "\nIP: "..ip..
            "\nThời Gian chạy  "..TimeEnd1.." Phút" .. " Tắt lúc " ..formattedFuture..
            "\nTìm kiếm lần " .. counTimkiem .. "/" .. randoocounTimkiem ..
            "\nXem comment lần"..counxemBinhLuan.."/"..randoocounxemBinhLuan..
            "\nGoto LIVE lần "..counxemLive.."/"..randoocounxemLive..
            "\nRepost video lần "..counrePost.."/"..randoocounrePost..
            "\nLướt video "..os.difftime(os.time(), startTime).."/"..time.." Giây",3)
            local x=random(136,600)
            --swipe(x, 621, "up", 0.2,150)
            tap(65, 1280);
            waitrandom(8,15)
            if os.difftime(os.time(), startTime) > time then
                break
            end
        end
    end

    function xemLive()
            check_Logout()
        if counxemLive < randoocounxemLive then
            if findimgs({"img/check_video_running.png"},2) then
                counxemLive = counxemLive + 1
                thongbao()
                tap(72, 83);
                wait(15,20)
                if countDay < 7 then
                    swipe(365, 621, "up", 0.1,150)
                    wait(30,60)
                end
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)  
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
                tap(65, 1280);
            end   
        else
            toast("Giới hạn Goto LIVE"..randoocounxemLive,2)
        end
    end

    function rePost()
        if counrePost < randoocounrePost then
            check_Logout()
            if findimgs({"img/check_video_running.png"},2) then
                counrePost = counrePost + 1
                thongbao()
                tap(697, 1029);
                usleep(2300167.83);
                tap(74, 1025);
                usleep(3102982.83);
                tap(404, 1229);
                usleep(5102982.83);
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)        
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
                tap(65, 1280);
            end   
        else
            toast("Giới hạn Goto LIVE "..randoocounrePost,2)
        end
    end
    local r_tuongtac = math.random(2, 4)
    if countDay < 7 then
        r_tuongtac = math.random(4, 5)
    end
    
    while 1<2 do
        local status = checkNetworkStatus()
        local mac = getMacAddress()
        if status == "online" then
            toast("Online", 4)
            reOpenTiktok()
            check_Logout()
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)          
            if findimgs({"img/check_video_running.png"},2) then
                swipe(426,496, "up", 0.1,200)
            else
                local orientation = frontMostAppOrientation();
                if orientation ~= bundleID then
                    appRun(bundleID)
                    usleep(15000000) 
                end
                openURL("snssdk1233://inbox")
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
                usleep(500000)
                tap(65, 1280);
                usleep(500000)
                tap(65, 1280);
            end
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
            luotvideo(math.random(60, 120))         
            local randoo = math.random(1, 6)
            toast("Lắc xí ngầu "..randoo,2)
            if randoo == 1 then
                usleep(2000000)
                toast("Bỏ Lượt",2)
            elseif randoo == 2 then
                clickLike()
            elseif randoo == 3 then
                xemBinhLuan()
            elseif randoo == 4 then
                clickLike()
                xemBinhLuan()
                xemLive()
            elseif randoo == 5 then
                rePost()
            elseif randoo == 6 then
                timkiem()
            end

        elseif status == "nowifi" then
            toast("❌ Không có IP (chưa kết nối mạng LAN/WiFi)", 4)
        elseif status == "no_internet" then
            toast("❌ no_internet", 4)
            appKill(bundleID);
             waitrandom(2,3)
            local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..mac.."|"))
            if string.find(stringProxy, "Remove proxy success") then toast("Remove proxy success",5) wait(3)end
            local proxy, err =getProxyInfo("proxysocks5",licham365(674),3)
                if proxy then
                    local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..mac.."|"..proxy..":socks"))
                    if string.find(stringProxy, "Update proxy success") then toast(proxy,5) reOpenTiktok() end
                end 
        else
            toast("❓ Trạng thái mạng không xác định", 3)
        end



            wait(2,3)           
        if os.difftime(os.time(), Timeauto) > TimeEnd then
                break
        end
    end   
end
autoTuongTac(6)
closeAllApp()
execute("rm -r "..Debug)
