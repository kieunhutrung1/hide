local lfs = require("lfs")
local curl = require("cURL")
local json = require("json")
local Debug = rootDir() .."/Debug/*"
execute("rm -r "..Debug)

function tap1(x, y, time)
    time = time or 1
    for i = 1, time do
    local a = random(1,9)
	local b = random(16000,17000)
    touchDown(a, x, y);
    usleep(b);
    touchUp(a, x, y);
    end
end
function tap(x, y, time, radius)
    radius = radius or 1
    time = time or 1
    for i = 1, time do
        local a = random(1, 9)
        local b = random(16000, 17000)
        -- Tạo tọa độ ngẫu nhiên trong hình tròn
        local angle = math.random() * 2 * math.pi       -- Góc ngẫu nhiên từ 0 đến 2π
        local r = radius * math.sqrt(math.random())     -- Bán kính ngẫu nhiên, căn bậc 2 để phân bố đều
        local offsetX = math.floor(r * math.cos(angle))
        local offsetY = math.floor(r * math.sin(angle))
        local randX = x + offsetX
        local randY = y + offsetY
        touchDown(a, randX, randY)
        usleep(b)
        touchUp(a, randX, randY)
    end
end
function swipe1(x1, y1, x2, y2, duration)
    local steps = 30
    local sleepTime = duration / steps
    local dx = (x2 - x1) / steps
    local dy = (y2 - y1) / steps

    touchDown(0, x1, y1)
    usleep(16570.67);
    for i = 1, steps do
        local moveX = x1 + dx * i
        local moveY = y1 + dy * i
        touchMove(4, moveX, moveY)
        usleep(sleepTime * 1000000)
    end
    usleep(16570.08);
    touchUp(0, x2, y2)
end
swipe = function(X, Y, direction, duration, distance)
    duration = duration or 0.3             -- Thời gian vuốt (giây)
    distance = distance or 200             -- Khoảng cách vuốt (pixel)
    local steps = 20                       -- Số bước chia nhỏ vuốt
    local delay = (duration / steps) * 1000000  -- Thời gian nghỉ giữa các bước (μs)
    local id = 1
    local dx, dy = 0, 0
    -- Xác định hướng vuốt
    if direction == "up" then
        dy = -distance
    elseif direction == "down" then
        dy = distance
    elseif direction == "left" then
        dx = -distance
    elseif direction == "right" then
        dx = distance
    else
        print("⚠️ Hướng không hợp lệ. Dùng: up, down, left, right")
        return
    end
    -- Tính tọa độ mỗi bước
    local stepX = dx / steps
    local stepY = dy / steps
    -- Bắt đầu vuốt
    touchDown(id, X, Y)
    for i = 1, steps do
        local moveX = X + stepX * i
        local moveY = Y + stepY * i
        touchMove(id, moveX, moveY)
        usleep(delay)
    end
    touchUp(id, X + dx, Y + dy)
    usleep(200000) -- Dừng lại 0.2s sau vuốt
end

function findimgs(imgs, wait, exact)
    exact = exact or 0.96
    local timenow2 = os.time()
    local i = wait
    repeat
        --toast("Wait " .. i .. "s", 1)
        i = i - 1
        for _, img in ipairs(imgs) do
            local result = findImage(img, 0, exact, nil, true)
            if #result > 0 then
                for j, v in ipairs(result) do
                    --toast("Thấy: " .. img .. "\nx=" .. v[1] .. ", y=" .. v[2], 3)
                    usleep(1000000)  -- đợi 1 giây cho người dùng kịp xem
                end
                execute("rm -r "..Debug)
                return true
            end
        end
        usleep(1000000)
    until (os.difftime(os.time(), timenow2) > wait)
    --toast("❌ Không tìm thấy hình", 2)
    execute("rm -r "..Debug)
    return false
end


function findimgsandclick(imgs, wait, exact)
    exact = exact or 0.96
    local timenow2 = os.time()
    local i = wait
    repeat
        --toast("Wait " .. i .. "s", 1)
        i = i - 1
        for _, img in ipairs(imgs) do
            local result = findImage(img, 0, exact, nil, true)
            if #result > 0 then
                for _, v in ipairs(result) do
                    local x = v[1]
                    local y = v[2]
                    --toast("📍 Found: " .. img .. "\nx=" .. x .. ", y=" .. y, 2)
                    usleep(500000)
                    -- Thực hiện click
                    tap(x,y)
                    --toast("✅ Đã click vào: " .. img, 2)
                    usleep(1000000)
                    execute("rm -r "..Debug)
                    return true
                end
            end
        end
        usleep(1000000)
    until (os.difftime(os.time(), timenow2) > wait)
    --toast("❌ Không tìm thấy hình nào", 2)
    execute("rm -r "..Debug)
    return false
end
function trim(s)
    return s:match("^%s*(.-)%s*$")
end
function split(inputstr, sep)
    if sep == nil then
        sep = "%s"  -- tách theo khoảng trắng mặc định
    end
    local t = {}
    for str in string.gmatch(inputstr, "([^" .. sep .. "]+)") do
        table.insert(t, str)
    end
    return t
end
function quickGetString1(url)
    local response = ""
    local c = curl.easy{
        url = url,
        writefunction = function(data)
            response = response .. data
            return true
        end
    }
    c:setopt_ssl_verifypeer(false)
    --c:setopt_ssl_verifyhost(false)
    local ok, err = pcall(function()
        c:perform()
    end)
    c:close()
    if not ok then
        toast(tostring(err), 3)
        return nil
    end
    --toast(response,3)
    return response  -- Dữ liệu dạng chuỗi, không phân tích
end
function quickGetString(url)
    local outputFile = rootDir() .. "/temp_api_result.txt"
    os.remove(outputFile)
    local cmd = string.format('curl -k -L "%s" -o "%s"', url, outputFile)
    execute(cmd)
    local f = io.open(outputFile, "r")
    if not f then
        toast("❌ Không lấy được kết quả", 3)
        return nil
    end
    local content = f:read("*a")
    f:close()
    --toast(content, 3)
    os.remove(outputFile)
    return content
end
function unescape_unicode(str)
    if str ~= nil then
        return str:gsub("\\u(%x%x%x%x)", function(code)
            return utf8.char(tonumber(code, 16))
        end)
    else
    return nil
    end
end
function filewrite(path, content)
    local file, err = io.open(path, "w")
    if not file then
        toast("Không thể mở file để ghi: " .. err, 20)
        return
    end
    if content == nil or content == "" then
        toast("Không thể mở file "..path.." để ghi: Content rỗng", 20)
        return
    end
    file:write(content)
    file:close()
end
function fileread(path)
    local file = io.open(path, "r")
    if file then
        local content = file:read("*l")
        file:close()
        return content;
    end
    return ""
end
function ensure_dir(path)
    local attr = lfs.attributes(path)
    if not attr or attr.mode ~= "directory" then
        execute("mkdir -p " .. path)
    end
end
function closeAllApp()
    local function keyPress(keyType)
        keyDown(keyType);
        usleep(10000);
        keyUp(keyType);
    end
    keyPress(KEY_TYPE.HOME_BUTTON);
    keyPress(KEY_TYPE.HOME_BUTTON);
    -- Lặp qua nhiều app
    for i = 1, 20 do
        touchDown(2, 451.61, 765.07);
        usleep(16384.08);
        touchMove(2, 446.48, 757.93);
        usleep(16740.83);
        touchMove(2, 446.48, 726.38);
        usleep(16776.71);
        touchMove(2, 507.04, 425.00);
        usleep(16501.04);
        touchMove(2, 538.86, 321.16);
        usleep(15456.83);
        touchUp(2, 542.96, 317.07);
        usleep(1000000)
    end
    keyPress(KEY_TYPE.HOME_BUTTON);
end
function urlEncode(str)
    return (str:gsub("([^%w%-_.~])", function(c)
        return string.format("%%%02X", string.byte(c))
    end))
end
function findBinaryValue(data, key)
    local pattern = key .. "%z/%z(.-)%z"
    return string.match(data, pattern)
end



 math.randomseed(os.time())
 function random(a,b)
	local rand=math.random(a,b)
	rand=math.random(a,b)
	rand=math.random(a,b)
	rand=math.random(a,b)
	rand=math.random(a,b)
	rand=math.random(a,b)

	return rand 
end
function wait(time1, time2)
    if time2 == nil then
        usleep(time1 * 1000000)
    else
        if time2 < time1 then
            time1, time2 = time2, time1  -- đảo nếu ngược
        end
        local randomTime = math.random() * (time2 - time1) + time1
        randomTime = math.random() * (time2 - time1) + time1
        randomTime = math.random() * (time2 - time1) + time1
        randomTime = math.random() * (time2 - time1) + time1
        randomTime = math.random() * (time2 - time1) + time1
        usleep(randomTime * 1000000)
    end
end

function waitrandom(time1,time2)
	local a = time1*1000
	local b = time2*1000
	local c = math.random(a,b)
	c = math.random(a,b)
	c = math.random(a,b)
	c = math.random(a,b)
	c = math.random(a,b)
	c = math.random(a,b)
	wait(c/1000)
end

function waitImage(image,t)
	local found = 0
	local time = 0
	while(found==0 and time<t) do
		local result=checkimage(image)
		if(result==false) then
			wait(1)
		else
			return result
		end
		time=time+1
	end
	return false
end
function checkimage(imagePath)
	local Path = rootDir().."/"
	-- Example:
	local region = {100, 100, 300, 300};
	local result = findImage(Path..imagePath, 2, 0.98, nil, false)
	local count=0;
	for i, v in pairs(result) do
		local x = v[1]; local y = v[2];
		count = count + 1;
	end
	if(count==0) then
		return false;
	else
		return result;
	end
end
function waitAndClick(image,t)
	local w, h = getScreenResolution();
	local click = 0
	local time = 0
	while(click==0 and time<t) do
		local result=checkimage(image)
		if(result==false) then
			wait(1)
		else
			tapC(result[1][1],result[1][2],1)
			click=1
			return true
		end
		time=time+1
	end
	return false
end

function waitImage(image,t)
	local found = 0
	local time = 0
	while(found==0 and time<t) do
		local result=checkimage(image)
		if(result==false) then
			wait(1)
		else
			return result
		end
		time=time+1
	end
	return false
end

function customInputPressIp6s(str)
			local result = {}
			--list toạ độ chữ
			local chu={a={74,1068},b={450,1178},c={300,1178},d={225,1068},e={188,958},f={300,1068},g={376,1068},h={450,1068},j={530,1068},i={560,958},k={595,1068},l={676,1068},m={600,1178},n={525,1178},o={638,958},p={715,958},q={36,958},r={260,958},s={150,1068},t={336,958},u={486,958},v={375,1178},w={112,958},x={224,1178},y={410,958},z={148,1178}}
			--list toạ độ số
			local so={{42,958},{114,958},{186,958},{261,958},{336,958},{413,958},{489,958},{562,958},{638,958}}
			so[0]={712,958} -- thêm số 0 vô list số
			local specialstring='.,?!-/:;()@' --list ký tự đặc biệt
			local specialstring1='[]{}#%^*+=_|~<>$' --list ký tự đặc biệt
			--specialstring1=specialstring1.."'"	-- thêm dấu ' và dấu cách vào list ký tự đặc biệt
			specialstring=specialstring.." " -- thêm dấu cách vào list ký tự đặc biệt
			-- list toạ độ ký tự đặc biệt
			local special1={{42,958},{114,958},{186,958},{261,958},{336,958},{413,958},{489,958},{562,958},{638,958},{712,958},{42,1068},{186,1068},{261,1068},{336,1068},{413,1068},{489,1068}}
			--{42,958},{114,958},{186,958},{261,958},{336,958},{413,958},{489,958},{562,958},{638,958},{712,958}
			local special={{164,1178},{268,1178},{374,1178},{478,1178},{42,1068},{114,1068},{186,1068},{261,1068},{336,1068},{413,1068},{638,1068},{400,1284}}
			for letter in str:gmatch(".") do table.insert(result, letter) end -- tách chuỗi ra từng ký tự
			for i,v in pairs(result) do -- duyệt từng ký tự trong chuỗi
				checknumber = tonumber(v) ~= nil -- kiểm tra có phải số không
				if(checknumber==true) then -- là số
					-- nhập số
					tap(42,1280) -- chuyển sang bàn phím số + ký tự
					wait(0.1)
					v=tonumber(v)
					tap(so[v][1],so[v][2])
					wait(0.1)
					tap(42,1280) -- chuyển về lại bàn phím chữ
					wait(0.1)
				else	-- không phải số
					-- kiểm tra chữ hay ký tự đặc biệt
					low=string.lower(v)
					up=string.upper(v)
					if(chu[low]~=nil) then
						-- kiểm tra chữ hoa chữ thường
						if(v==up) then
							-- nhập chữ hoa
							tap(48,1178) -- bấm nút mũi tên
							wait(0.15)
							tap(chu[low][1],chu[low][2])
						else
							-- nhập chữ thường
							tap(chu[low][1],chu[low][2])
						end
					else
						-- nhập ký tự đặc biệt
						k=string.find(specialstring,"%"..v)
						if(k~=nil) then
							if(v~=" ") then
								tap(42,1280) -- chuyển sang bàn phím số + ký tự
								wait(0.5)
							end
							tap(special[k][1],special[k][2])
							wait(0.1)
							if(v~="'" and v~=" ") then
								tap(42,1280) -- chuyển về lại bàn phím chữ
								wait(0.2)
							end
						end
						-- nhập ký tự đặc biệt
						k1=string.find(specialstring1,"%"..v)
						if(k1~=nil) then
							if(v~=" ") then
								tap(42,1280) -- chuyển sang bàn phím số + ký tự
								wait(0.5)
								tap(45,1178)
								wait(0.5)
							end
							tap(special1[k1][1],special1[k1][2])
							wait(0.1)
							tap(42,1280) -- chuyển về lại bàn phím chữ
							wait(0.5)
						end
					end
				end
				waitrandom(0.3,0.5)
			end
end

function getUid(apps)
local resultTiktokInfo = appInfo(apps)
local basePath = string.gsub(resultTiktokInfo["dataContainerPath"], "file://", "");
local basePath = basePath.."Documents"
    local lfs = require("lfs")
    if type(basePath) ~= "string" or basePath == "" then
        toast("basePath rỗng hoặc không hợp lệ",5)
        return ""
    end
    local attr = lfs.attributes(basePath)
    if not attr then
        toast("Đường dẫn không tồn tại: " .. basePath,5)
        return ""
    elseif attr.mode ~= "directory" then
        toast("Không phải là thư mục: " .. basePath,5)
        return ""
    end
    local function isNumeric19(str)
        return #str == 19 and string.match(str, "^%d+$")
    end
    local latestFolder = ""
    local latestTime = 0
    local found = false
    for file in lfs.dir(basePath) do
        if file ~= "." and file ~= ".." then
            local fullPath = basePath .. "/" .. file
            local attr = lfs.attributes(fullPath)
            if attr and attr.mode == "directory" and isNumeric19(file) then
                found = true
                if attr.modification > latestTime then
                    latestTime = attr.modification
                    latestFolder = file
                end
            end
        end
    end
    if not found then
        toast("Không tìm thấy thư mục hợp lệ trong: " .. basePath,5)
        return ""
    end
    return latestFolder
end
function licham365(stt)
local stringAPI = unescape_unicode(quickGetString("https://licham365.com/clone/users/"..stt.."/check"))
    if string.find(stringAPI, "success") then
        local data = string.match(stringAPI, '"data"%s*:%s*"([^"]+)"')
        return data
    else
        local message = string.match(stringAPI, '"data"%s*:%s*"([^"]+)"')
        return message ,nil or "Lỗi không xác định"
    end
end
function changescript(url)
	local cURL = require("cURL")
	headers = {
	  "Accept: text/*",
	  "Accept-Language: en",
	  "Accept-Charset: iso-8859-1,*,utf-8",
	  "Cache-Control: no-cache"
	}
	login_url = url
	c = cURL.easy{
	  url            = login_url,
	  ssl_verifypeer = false,
	  ssl_verifyhost = false,
	  httpheader     = headers,
	  writefunction  = function(str)
		succeed = succeed or (string.find(str, "srcId:%s+SignInAlertSupressor--"))
	  end
	}
	c:perform()	
end
function checkCountry1()
        local result = unescape_unicode(quickGetString("https://ipinfo.io/json"))
        local country = string.match(result, '"country"%s*:%s*"([^"]+)"')
        local ip = string.match(result, '"ip"%s*:%s*"([^"]+)"')
        local city = string.match(result, '"city"%s*:%s*"([^"]+)"')
        local countryCode = string.match(result, '"country"%s*:%s*"([^"]+)"')
        toast(city.."-"..country..
              "\n"..ip,10)
        return countryCode
end
function checkCountry()
        local result = unescape_unicode(quickGetString("http://ip-api.com/json"))
        local country = string.match(result, '"country"%s*:%s*"([^"]+)"')
        local ip = string.match(result, '"query"%s*:%s*"([^"]+)"')
        local city = string.match(result, '"city"%s*:%s*"([^"]+)"')
        local countryCode = string.match(result, '"countryCode"%s*:%s*"([^"]+)"')
        toast(city.."-"..country..
              "\n"..ip,10)
        return countryCode
end
function getMacAddress()
    local raw = execute("ifconfig en0")
    if not raw or raw == "" then
        return nil  -- Không lấy được dữ liệu ifconfig
    end
    local mac = string.match(raw, "ether%s+(%x+:%x+:%x+:%x+:%x+:%x+)")
    if mac and mac ~= "" then
        return mac  -- Trả về địa chỉ MAC nếu tìm thấy
    else
        return nil  -- Không tìm thấy MAC
    end
end
function checkNetworkStatus()
    local raw = execute("ifconfig en0")
    local ip = string.match(raw or "", "inet%s+(%d+%.%d+%.%d+%.%d+)")
    if not ip then
        return "nowifi"  -- Không có IP, không kết nối LAN/WiFi
    end
    local pingResult = execute("ping -c 1 -W 1 8.8.8.8")
    local hasPing = string.find(pingResult or "", "1 received") or string.find(pingResult or "", "0%% packet loss")
    local webResult = quickGetString("http://clients3.google.com/generate_204")
    local hasHTTP = (webResult == "")
    if hasPing or hasHTTP then
        return "online"
    else
        return "no_internet"  -- Có IP nhưng không ra Internet
    end
end
function waitcolorText(...)
  local args = {...}
  local totalArgs = #args
  -- Lấy ra 3 tham số cấu hình cuối cùng
  local maxAttempts = args[totalArgs - 2]  -- Số lần thử lại
  local showToast = args[totalArgs - 1]    -- Hiển thị thông báo toast
  local toastMessage = args[totalArgs]     -- Nội dung toast
  local attempt = 1
  repeat
    for i = 1, totalArgs - 3, 3 do
      local x = args[i]
      local y = args[i + 1]
      local expectedColor = args[i + 2]

      if showToast == 1 then
        toast(toastMessage .. "..  " .. attempt, 1)
      end
      if getColor(x, y) == expectedColor then
        usleep(1000000)
        return x, y
      end
    end
    attempt = attempt + 1
    usleep(1000000)
  until attempt > maxAttempts
  return nil
end
function Check_Color(flatCoords)
    local coords = {}
    for i = 1, #flatCoords, 2 do
        table.insert(coords, {flatCoords[i], flatCoords[i + 1]})
    end
    local colors = getColors(coords)
    local parts = {}
    for i, color in ipairs(colors) do
        local x, y = coords[i][1], coords[i][2]
        table.insert(parts, string.format("%d, %d, %d", x, y, color))
    end
    -- Thêm mặc định: 20 lần thử, hiện toast, thông báo rỗng
    table.insert(parts, "20, 1, \"\"")
    local final = "waitcolorText(" .. table.concat(parts, ", ") .. ")"
    toast(final,3)
    log(final)
end