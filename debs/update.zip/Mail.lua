local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local tiktokID = getUid("com.ss.iphone.ugc.Ame")
local customID = fileread(rootDir() .. "/libs/domail.txt")
keepAutoTouchAwake(true);

function newmail()
    appRun("com.ss.iphone.ugc.Ame")
    execute("rm -r "..rootDir() .. "/libs/domail.txt")
    local raw = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/getmaildomain.php"))
    raw = string.gsub(raw, '%[', '')
    raw = string.gsub(raw, '%]', '')
    raw = string.gsub(raw, '"', '')
    local domains = {}
    for domain in string.gmatch(raw, '([^,]+)') do
        table.insert(domains, domain)
    end
    math.randomseed(os.time())
    local r = math.random(1, #domains)
    local selected = domains[r]
    local email = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/newmail.php?domain="..selected.."&prefix="))
    copyText(email)
    toast("📧 Email mới: " .. email, 3)
    filewrite(rootDir() .. "/libs/domail.txt", email)
    return email
end
function getotp()
    appRun("com.ss.iphone.ugc.Ame")
    email = fileread(rootDir() .. "/libs/domail.txt")
    email = split(email, "@")
    local stringAPI = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/getotp.php?domain="..email[2].."&email="..email[1]))
    --local stringAPI = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/getotp.php?domain=zecto.net&email=crcpzue1"))
    if string.find(stringAPI, "subject") then
        local subject = string.match(stringAPI, '"subject"%s*:%s*"([^"]+)"')
        local code = string.match(subject, "(%d%d%d%d%d%d)")
        copyText(code)
        toast(code, 5)
    end
end
function SaveApi()
    appRun("com.ss.iphone.ugc.Ame")
    local stringAPI = unescape_unicode(quickGetString("https://script.google.com/macros/s/AKfycbz3l9qX0AFPmGBIsaziaMOsPLyBKAzydpsNbOS0rbbfk3cpQWR9DysThw9IT8v5mEtj/exec?sheet=DOMAIL&mail_domain="..customID.."&note_domain="..clipText().."&UID="..tiktokID))
    if string.find(stringAPI, "success") then
    toast("Lưu vào dòng : "..tonumber(string.match(stringAPI, '"row"%s*:%s*(%d+)')), 5)
    end
end
function login()
        local startAt_login = {type=CONTROLLER_TYPE.INPUT, title="UID", key="startAt_login", value=customID}
        local lb_empty = {type=CONTROLLER_TYPE.LABEL, text=" "}
        local bt_newmail = {type=CONTROLLER_TYPE.BUTTON, title="Lấy Email", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
        local bt_otp = {type=CONTROLLER_TYPE.BUTTON, title="Get OTP", color=0x4542f5, width=1.0, flag=2, collectInputs=true}
        local bt_saveMail = {type=CONTROLLER_TYPE.BUTTON, title="Save Email", color=0x4542f5, width=1.0, flag=3, collectInputs=true}
        local bt_Zxcv = {type=CONTROLLER_TYPE.BUTTON, title="Zxcv123123", color=0x4542f5, width=1.0, flag=4, collectInputs=true}
        local bt_cancel = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0xff66ff, width=1.0, flag=5, collectInputs=true}
        local controls_login = {bt_newmail, bt_otp, bt_saveMail,bt_Zxcv,bt_cancel,startAt_login,lb_empty}
        local orientations_login = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
        result_dialog_login = dialog(controls_login, orientations_login);
        if (result_dialog_login == 1) then
            newmail()
        elseif (result_dialog_login == 2) then
            getotp()
        elseif (result_dialog_login == 3) then
            SaveApi()
        elseif (result_dialog_login == 4) then
            appRun("com.ss.iphone.ugc.Ame")
            copyText("Zxcv123123@")
            toast(clipText(), 5)
        elseif (result_dialog_login == 5) then
            stop();
        end
end
login()