local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local customID = fileread(rootDir() .. "/libs/domail.txt")
local uid = getUid("com.ss.iphone.ugc.Ame")
keepAutoTouchAwake(true);
function newmail()
    appRun("com.ss.iphone.ugc.Ame")
    execute("rm -r "..rootDir() .. "/libs/domail.txt")
    local raw = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/getmaildomain.php"))
    raw = string.gsub(raw, '%[', '')
    raw = string.gsub(raw, '%]', '')
    raw = string.gsub(raw, '"', '')
    local domains = {}
    for domain in string.gmatch(raw, '([^,]+)') do
        table.insert(domains, domain)
    end
    math.randomseed(os.time())
    local r = math.random(1, #domains)
    local selected = domains[r]
    local email = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/newmail.php?domain="..selected.."&prefix="))
    copyText(email)
    toast("📧 Email mới: " .. email, 3)
    filewrite(rootDir() .. "/libs/domail.txt", email)
    return email
end
function getotpsearch()
    appRun("com.ss.iphone.ugc.Ame")
    local data = searchGG("DOMAIL","UID",uid)
    data = string.match(data, '"mail_domain"%s*:%s*"([^"]+)"')
    toast(data, 3)
    email = split(data, "@")
    local stringAPI = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/getotp.php?domain="..email[2].."&email="..email[1]))
    --toast(stringAPI, 10)
    if string.find(stringAPI, "subject") then
        local subject = string.match(stringAPI, '"subject"%s*:%s*"([^"]+)"')
        local code = string.match(subject, "(%d%d%d%d%d%d)")
        copyText(code)
        toast(code, 5)
    else
        toast(stringAPI,5)
    end
end
function getotpsearch2fa()
    appRun("com.ss.iphone.ugc.Ame")
    local data = searchGG("2FA","UID",uid)
    data = string.match(data, '"2FA"%s*:%s*"([^"]+)"')
    local stringAPI = unescape_unicode(quickGetString("https://2fa.live/tok/"..data))
    local token = string.match(stringAPI, '"token"%s*:%s*"([^"]+)"')
    copyText(token)
    
end
function on2fa()
    unlock()
    copyText("");
    openURL("snssdk1233://setting")
    local cookie = cookie(bundleID)
    wait(3,5)
    if findimgsandclick({"img/bt_security.png"}, 20) then
        wait(3,5)
        if findimgsandclick({"img/bt_off.png","img/bt_off1.png"}, 20) then
            if findimgsandclick({"img/bt_security.png"}, 20) then
                if waitcolorText(95, 1265, 16657493, 369, 1241, 16657493, 650, 1265, 16657493, 20, 1, "BT Turn on") then tap(369, 1241)
                    if findimgsandclick({"img/bt_copy_key.png","img/bt_copy_key1.png","img/bt_copy_key2.png"}, 20) then
                        local data = clipText()
                        toast(data, 3)
                        if data ~= "" then
                            if waitcolorText(95, 1265, 16657493, 369, 1241, 16657493, 650, 1265, 16657493, 20, 1, "BT Next") then tap(369, 1241)
                                local stringAPI = unescape_unicode(quickGetString("https://2fa.live/tok/"..data))
                                local token = string.match(stringAPI, '"token"%s*:%s*"([^"]+)"')
                                if token ~= nil then 
                                    toast(token, 3)
                                    local stringAPI = unescape_unicode(quickGetString("https://script.google.com/macros/s/AKfycbz3l9qX0AFPmGBIsaziaMOsPLyBKAzydpsNbOS0rbbfk3cpQWR9DysThw9IT8v5mEtj/exec?sheet=2FA&UID="..uid.."&SN="..getSN().."&2FA="..data.."&Token="..cookie))
                                    if string.find(stringAPI, "success") then
                                    toast("Lưu vào dòng : "..tonumber(string.match(stringAPI, '"row"%s*:%s*(%d+)')), 5)
                                    wait(3)
                                    tapNumber(token)
                                    wait(3,5)
                                    tap(680,85)
                                    if waitcolorText(95, 1265, 16657493, 369, 1241, 16657493, 650, 1265, 16657493, 20, 1, "BT Turn on") then tap(369, 1241) end
                                    else
                                        toast("Lỗi không phản hồi api",5)
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end
function getotp(data)
    appRun("com.ss.iphone.ugc.Ame")
    --email = fileread(rootDir() .. "/libs/domail.txt")
    email = split(data, "@")
    local stringAPI = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/getotp.php?domain="..email[2].."&email="..email[1]))
    --local stringAPI = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/getotp.php?domain=zecto.net&email=crcpzue1"))
    if string.find(stringAPI, "subject") then
        local subject = string.match(stringAPI, '"subject"%s*:%s*"([^"]+)"')
        local code = string.match(subject, "(%d%d%d%d%d%d)")
        copyText(code)
        toast(code, 5)
    else
        toast(stringAPI,5)
    end
end
function clean()
    local tiktokID = getUid("com.ss.iphone.ugc.Ame")
    local resultTiktokInfo = appInfo("com.ss.iphone.ugc.Ame")
    local basePath = string.gsub(resultTiktokInfo["dataContainerPath"], "file://", "")
    execute("rm -r '" .. basePath .. "/Library/Application Support'")
    execute("rm -r '" .. basePath .. "/Library/Caches'")
    copyText(tiktokID)
    appRun("com.tigisoftware.ADManager")
end
function SaveApi(data1)
    local tiktokID = getUid("com.ss.iphone.ugc.Ame")
    execute("rm -r "..rootDir() .. "/libs/uid.txt")
    local data2 = clipText()
    if not data2 then data2 = "" end
    local resultTiktokInfo = appInfo("com.ss.iphone.ugc.Ame")
    local basePath = string.gsub(resultTiktokInfo["dataContainerPath"], "file://", "")
    local cookiePath = basePath .. "/Library/Cookies/Cookies.binarycookies"
    local file = io.open(cookiePath, "rb")
    if not file then
        toast("❌ Không tìm thấy file Cookies.binarycookies: " .. cookiePath, 5)
        return
    end
    local data = file:read("*all")
    file:close()
    local pos = string.find(data, "sessionid")
    if not pos then
        toast("❌ Không tìm thấy sessionid", 5)
        return
    end
    local tail = string.sub(data, pos + 9, pos + 100)
    local session_value = findBinaryValue(data, "sessionid")
    if not session_value then
        session_value = findBinaryValue(data, "sessionid_ss")
    end
    local keys = {
        "odin_tt", "store-idc", "store-country-code", "store-country-code-src", "store-country-sign",
        "passport_csrf_token", "passport_csrf_token_default", "tt-target-idc", "tt-target-idc-sign",
        "multi_sids", "sid_guard", "uid_tt", "uid_tt_ss", "sid_tt",
        "sessionid_ss", "msToken"
    }
    local result = { ["sessionid"] = session_value }
    for _, key in ipairs(keys) do
        local val = findBinaryValue(data, key)
        if val then
            result[key] = val
        end
    end
    local parts = {}
    for k, v in pairs(result) do
        table.insert(parts, k .. "=" .. urlEncode(v))
    end
    local resultString = table.concat(parts, "; ")
    local resultString = urlEncode(resultString)
    local stringAPI = unescape_unicode(quickGetString("https://script.google.com/macros/s/AKfycbz3l9qX0AFPmGBIsaziaMOsPLyBKAzydpsNbOS0rbbfk3cpQWR9DysThw9IT8v5mEtj/exec?sheet=DOMAIL&mail_domain="..data1.."&note_domain="..data2.."&UID="..tiktokID.."&SN="..getSN().."&Token="..resultString))
    filewrite(rootDir() .. "/libs/uid.txt", tiktokID)
    if string.find(stringAPI, "success") then
    toast("Lưu vào dòng : "..tonumber(string.match(stringAPI, '"row"%s*:%s*(%d+)')), 5)
    else
        toast("Lỗi không phản hồi api",5)
    end
end

function login()
        local startAt_login = {type=CONTROLLER_TYPE.INPUT, title="UID", key="startAt_login", value=customID}
        local lb_empty = {type=CONTROLLER_TYPE.LABEL, text=" "}
        local bt_1 = {type=CONTROLLER_TYPE.BUTTON, title="Lấy Email", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
        local bt_2 = {type=CONTROLLER_TYPE.BUTTON, title="Coppy Email", color=0x4542f5, width=1.0, flag=6, collectInputs=true}
        local bt_3 = {type=CONTROLLER_TYPE.BUTTON, title="Get OTP", color=0x4542f5, width=1.0, flag=2, collectInputs=true}
        local bt_4 = {type=CONTROLLER_TYPE.BUTTON, title="Get OTP UID", color=0x4542f5, width=1.0, flag=10, collectInputs=true}
        local bt_5 = {type=CONTROLLER_TYPE.BUTTON, title="Save Email", color=0x4542f5, width=1.0, flag=3, collectInputs=true}
        local bt_6 = {type=CONTROLLER_TYPE.BUTTON, title="Zxcv123123", color=0x4542f5, width=1.0, flag=4, collectInputs=true}
        local bt_7 = {type=CONTROLLER_TYPE.BUTTON, title="Open Profile", color=0x4542f5, width=1.0, flag=7, collectInputs=true}
        local bt_8 = {type=CONTROLLER_TYPE.BUTTON, title="Save Profile", color=0x4542f5, width=1.0, flag=8, collectInputs=true}
        local bt_9 = {type=CONTROLLER_TYPE.BUTTON, title="Clean data", color=0x4542f5, width=1.0, flag=9, collectInputs=true}
        local bt_10 = {type=CONTROLLER_TYPE.BUTTON, title="ON 2FA", color=0x4542f5, width=1.0, flag=11, collectInputs=true}
        local bt_11 = {type=CONTROLLER_TYPE.BUTTON, title="Get Code 2FA", color=0x4542f5, width=1.0, flag=12, collectInputs=true}
        local bt_cancel = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0xff66ff, width=1.0, flag=5, collectInputs=true}
        local controls_login = {bt_1, bt_2, bt_3, bt_4, bt_5,bt_6,bt_7,bt_8,bt_9,bt_10,bt_11,bt_cancel,startAt_login,lb_empty}
        local orientations_login = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
        result_dialog_login = dialog(controls_login, orientations_login);
        if (result_dialog_login == 1) then
             appRun("com.ss.iphone.ugc.Ame")
            newmail()
        elseif (result_dialog_login == 2) then
            appRun("com.ss.iphone.ugc.Ame")
            getotp(startAt_login.value)
        elseif (result_dialog_login == 3) then
            SaveApi(startAt_login.value)
        elseif (result_dialog_login == 4) then
            appRun("com.ss.iphone.ugc.Ame")
            copyText("Zxcv123123@")
            toast(clipText(), 5)
        elseif (result_dialog_login == 5) then
            stop();
        elseif (result_dialog_login == 6) then
            appRun("com.ss.iphone.ugc.Ame")
            copyText(startAt_login.value)
        elseif (result_dialog_login == 7) then
            local tiktokID = getUid("com.ss.iphone.ugc.Ame")
            openURL("snssdk1233://user/profile/"..tiktokID)
        elseif (result_dialog_login == 8) then
            execute("rm -r "..rootDir() .. "/libs/uid.txt")
            filewrite(rootDir() .. "/libs/uid.txt", tiktokID)
        elseif (result_dialog_login == 9) then
            clean()
        elseif (result_dialog_login == 10) then
            getotpsearch()
        elseif (result_dialog_login == 11) then
            on2fa()
        elseif (result_dialog_login == 12) then
            getotpsearch2fa()
        end
end
login()