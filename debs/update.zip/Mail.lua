local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local tiktokID = getUid("com.ss.iphone.ugc.Ame")
local customID = fileread(rootDir() .. "/libs/domail.txt")
keepAutoTouchAwake(true);

function newmail()
    appRun("com.ss.iphone.ugc.Ame")
    execute("rm -r "..rootDir() .. "/libs/domail.txt")
    local raw = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/getmaildomain.php"))
    raw = string.gsub(raw, '%[', '')
    raw = string.gsub(raw, '%]', '')
    raw = string.gsub(raw, '"', '')
    local domains = {}
    for domain in string.gmatch(raw, '([^,]+)') do
        table.insert(domains, domain)
    end
    math.randomseed(os.time())
    local r = math.random(1, #domains)
    local selected = domains[r]
    local email = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/newmail.php?domain="..selected.."&prefix="))
    copyText(email)
    toast("📧 Email mới: " .. email, 3)
    filewrite(rootDir() .. "/libs/domail.txt", email)
    return email
end
function getotp(data)
    appRun("com.ss.iphone.ugc.Ame")
    --email = fileread(rootDir() .. "/libs/domail.txt")
    email = split(data, "@")
    local stringAPI = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/getotp.php?domain="..email[2].."&email="..email[1]))
    --local stringAPI = unescape_unicode(quickGetString("https://ssms.hpmegagoal.com/mail/getotp.php?domain=zecto.net&email=crcpzue1"))
    if string.find(stringAPI, "subject") then
        local subject = string.match(stringAPI, '"subject"%s*:%s*"([^"]+)"')
        local code = string.match(subject, "(%d%d%d%d%d%d)")
        copyText(code)
        toast(code, 5)
    else
        toast(stringAPI,5)
    end
end
function clean()
    local resultTiktokInfo = appInfo("com.ss.iphone.ugc.Ame")
    local basePath = string.gsub(resultTiktokInfo["dataContainerPath"], "file://", "")
    execute("rm -r '" .. basePath .. "/Library/Application Support'")
    execute("rm -r '" .. basePath .. "/Library/Caches'")
    copyText(tiktokID)
    appRun("com.tigisoftware.ADManager")
end
function SaveApi(data1)
    execute("rm -r "..rootDir() .. "/libs/uid.txt")
    local data2 = clipText()
    if not data2 then data2 = "" end
    local resultTiktokInfo = appInfo("com.ss.iphone.ugc.Ame")
    local basePath = string.gsub(resultTiktokInfo["dataContainerPath"], "file://", "")
    local cookiePath = basePath .. "/Library/Cookies/Cookies.binarycookies"
    local file = io.open(cookiePath, "rb")
    if not file then
        toast("❌ Không tìm thấy file Cookies.binarycookies: " .. cookiePath, 5)
        return
    end
    local data = file:read("*all")
    file:close()
    local pos = string.find(data, "sessionid")
    if not pos then
        toast("❌ Không tìm thấy sessionid", 5)
        return
    end
    local tail = string.sub(data, pos + 9, pos + 100)
    local session_value = findBinaryValue(data, "sessionid")
    if not session_value then
        session_value = findBinaryValue(data, "sessionid_ss")
    end
    local keys = {
        "odin_tt", "store-idc", "store-country-code", "store-country-code-src", "store-country-sign",
        "passport_csrf_token", "passport_csrf_token_default", "tt-target-idc", "tt-target-idc-sign",
        "multi_sids", "sid_guard", "uid_tt", "uid_tt_ss", "sid_tt",
        "sessionid_ss", "msToken"
    }
    local result = { ["sessionid"] = session_value }
    for _, key in ipairs(keys) do
        local val = findBinaryValue(data, key)
        if val then
            result[key] = val
        end
    end
    local parts = {}
    for k, v in pairs(result) do
        table.insert(parts, k .. "=" .. urlEncode(v))
    end
    local resultString = table.concat(parts, "; ")
    local resultString = urlEncode(resultString)
    local stringAPI = unescape_unicode(quickGetString("https://script.google.com/macros/s/AKfycbz3l9qX0AFPmGBIsaziaMOsPLyBKAzydpsNbOS0rbbfk3cpQWR9DysThw9IT8v5mEtj/exec?sheet=DOMAIL&mail_domain="..data1.."&note_domain="..data2.."&UID="..tiktokID.."&SN="..getSN().."&Token="..resultString))
    filewrite(rootDir() .. "/libs/uid.txt", tiktokID)
    if string.find(stringAPI, "success") then
    toast("Lưu vào dòng : "..tonumber(string.match(stringAPI, '"row"%s*:%s*(%d+)')), 5)
    else
        toast("Lỗi không phản hồi api",5)
    end
end

function login()
        local startAt_login = {type=CONTROLLER_TYPE.INPUT, title="UID", key="startAt_login", value=customID}
        local lb_empty = {type=CONTROLLER_TYPE.LABEL, text=" "}
        local bt_newmail = {type=CONTROLLER_TYPE.BUTTON, title="Lấy Email", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
        local bt_mail = {type=CONTROLLER_TYPE.BUTTON, title="Coppy Email", color=0x4542f5, width=1.0, flag=6, collectInputs=true}
        local bt_otp = {type=CONTROLLER_TYPE.BUTTON, title="Get OTP", color=0x4542f5, width=1.0, flag=2, collectInputs=true}
        local bt_saveMail = {type=CONTROLLER_TYPE.BUTTON, title="Save Email", color=0x4542f5, width=1.0, flag=3, collectInputs=true}
        local bt_Zxcv = {type=CONTROLLER_TYPE.BUTTON, title="Zxcv123123", color=0x4542f5, width=1.0, flag=4, collectInputs=true}
        local bt_op = {type=CONTROLLER_TYPE.BUTTON, title="Open Profile", color=0x4542f5, width=1.0, flag=7, collectInputs=true}
        local bt_save = {type=CONTROLLER_TYPE.BUTTON, title="Save Profile", color=0x4542f5, width=1.0, flag=8, collectInputs=true}
        local bt_data = {type=CONTROLLER_TYPE.BUTTON, title="Clean data", color=0x4542f5, width=1.0, flag=9, collectInputs=true}
        local bt_cancel = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0xff66ff, width=1.0, flag=5, collectInputs=true}
        local controls_login = {bt_newmail, bt_mail, bt_otp, bt_saveMail,bt_Zxcv,bt_op,bt_save,bt_data,bt_cancel,startAt_login,lb_empty}
        local orientations_login = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
        result_dialog_login = dialog(controls_login, orientations_login);
        if (result_dialog_login == 1) then
            newmail()
        elseif (result_dialog_login == 2) then
            getotp(startAt_login.value)
        elseif (result_dialog_login == 3) then
            SaveApi(startAt_login.value)
        elseif (result_dialog_login == 4) then
            appRun("com.ss.iphone.ugc.Ame")
            copyText("Zxcv123123@")
            toast(clipText(), 5)
        elseif (result_dialog_login == 5) then
            stop();
        elseif (result_dialog_login == 6) then
            appRun("com.ss.iphone.ugc.Ame")
            copyText(startAt_login.value)
        elseif (result_dialog_login == 7) then
            openURL("snssdk1233://user/profile/"..fileread(rootDir() .. "/libs/uid.txt"))
        elseif (result_dialog_login == 8) then
            execute("rm -r "..rootDir() .. "/libs/uid.txt")
            filewrite(rootDir() .. "/libs/uid.txt", tiktokID)
        elseif (result_dialog_login == 9) then
            clean()
        end
end
login()