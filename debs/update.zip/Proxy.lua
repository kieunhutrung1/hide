local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local tiktokID = getUid("com.ss.iphone.ugc.Ame")
local customID = fileread(rootDir() .. "/libs/domail.txt")
keepAutoTouchAwake(true);



function getProxyInfo(proxyType,key,tinhthanh)
    -- Mặc định nếu không truyền gì → lấy socks5
    proxyType = proxyType or "socks5"
    -- Gọi API
    local url = "https://proxyxoay.shop/api/get.php?key="..key.."&&nhamang=random&&tinhthanh="..tinhthanh
    local response = unescape_unicode(quickGetString(url))
    -- Kiểm tra dữ liệu
    if not response or response == "" then
        return nil, "Không nhận được phản hồi từ API"
    end
    if not string.find(response, '"status"%s*:%s*100') then
        return nil 
    end
    -- Xác định trường proxy cần lấy
    local proxyKey = proxyType == "http" and "proxyhttp" or "proxysocks5"
    local proxy = string.match(response, '"' .. proxyKey .. '"%s*:%s*"([^"]+)"')
    local message = string.match(response, '"message"%s*:%s*"([^"]+)"')
    local viTri = string.match(response, '"Vi Tri"%s*:%s*"([^"]+)"')
    local expire = string.match(response, '"Token expiration date"%s*:%s*"([^"]+)"')
    if not proxy then
        return nil, "Không tìm thấy proxy loại: " .. proxyKey
    end
    return proxy
end
function main()
    local label = {type=CONTROLLER_TYPE.LABEL, text="Proxy ver 0.1"}
    local nameInput = {type=CONTROLLER_TYPE.INPUT, title="Proxy:", key="Name", value="Bob"}
    local btn1 = {type=CONTROLLER_TYPE.BUTTON, title="Lấy Proxy", color=0x71C69E, width=0.8, flag=1, collectInputs=false}
    local btn2 = {type=CONTROLLER_TYPE.BUTTON, title="Xóa Proxy", color=0x71C69E, width=0.8, flag=2, collectInputs=false}
    local btn3 = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0xFF5733, flag=3, collectInputs=false}
    local controls = { label,nameInput, btn1,btn2,btn3}
    local orientations = {  ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
    local result = dialog(controls, orientations);
    if (result == 1) then
        local proxy, err =getProxyInfo("proxysocks5",licham365(674),3)
        if proxy then
            local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..getMacAddress().."|"..proxy..":socks"))
            if string.find(stringProxy, "Update proxy success") then toast("NV: "..stringProxy,5)  checkCountry() end
        end
    elseif (result == 2) then
        local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..getMacAddress().."|"))
        if string.find(stringProxy, "Remove proxy success") then toast("Remove proxy success",5)end
    elseif (result == 3) then
        stop();
    end
end
main()