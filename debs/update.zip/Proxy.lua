local app = require("libs/support") 
local lfs = require("lfs")
keepAutoTouchAwake(true);
function getProxyInfo(proxyType,key,tinhthanh)
    -- Mặc định nếu không truyền gì → lấy socks5
    proxyType = proxyType or "socks5"
    -- Gọi API
    local url = "https://proxyxoay.shop/api/get.php?key="..key.."&&nhamang=random&&tinhthanh="..tinhthanh
    local response = unescape_unicode(quickGetString(url))
    -- Kiểm tra dữ liệu
    if not response or response == "" then
        return nil, "Không nhận được phản hồi từ API"
    end
    if not string.find(response, '"status"%s*:%s*100') then
        return nil 
    end
    -- Xác định trường proxy cần lấy
    local proxyKey = proxyType == "http" and "proxyhttp" or "proxysocks5"
    local proxy = string.match(response, '"' .. proxyKey .. '"%s*:%s*"([^"]+)"')
    local message = string.match(response, '"message"%s*:%s*"([^"]+)"')
    local viTri = string.match(response, '"Vi Tri"%s*:%s*"([^"]+)"')
    local expire = string.match(response, '"Token expiration date"%s*:%s*"([^"]+)"')
    if not proxy then
        return nil, "Không tìm thấy proxy loại: " .. proxyKey
    end
    return proxy
end
local status = checkNetworkStatus()
local mac = getMacAddress()
if status == "online" then
    toast("Online", 4)
    local proxy, err =getProxyInfo("proxysocks5",licham365(674),3)
        if proxy then
            local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..mac.."|"..proxy..":socks"))
            if string.find(stringProxy, "Update proxy success") then toast(proxy,5) end
        end
elseif status == "nowifi" then
    toast("❌ Không có IP (chưa kết nối mạng LAN/WiFi)", 4)
elseif status == "no_internet" then
    toast("❌ no_internet", 4)
    local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..mac.."|"))
    if string.find(stringProxy, "Remove proxy success") then toast("Remove proxy success",5) wait(3)end
     local proxy, err =getProxyInfo("proxysocks5",licham365(674),3)
        if proxy then
            local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..mac.."|"..proxy..":socks"))
            if string.find(stringProxy, "Update proxy success") then toast(proxy,5) end
        end 
else
    toast("❓ Trạng thái mạng không xác định", 3)
end
