local app = require("libs/support")
local Debug = rootDir() .. "/Debug/*"
ip = getLocalIP()
function run(lua,remote)
    remote = remote or 1
    if remote == 1 then
    lenh =  "start"
    elseif remote == 2 then
    lenh =  "stop"
    end
    local ip = getLocalIP()   -- ví dụ: "192.168.1.25"
    local subnet = string.match(ip, "(%d+%.%d+%.%d+%.)")
    -- In dải IP từ .2 đến .255
    for i = 2, 255 do
        local full = subnet .. i
        if full == ip then 
        else
        local url = 'http://'..full..':8080/control/'..lenh..'_playing?path=%2F'..lua
        local cmd = string.format('curl -s -k -L --connect-timeout 1 -m 1 -o /dev/null "%s"', url)
        execute(cmd)
        --openURL(url)
        toast(url, 1)
        --wait(1.5)
        end
    end
    --openURL('http://'..ip..':8080/control/'..lenh..'_playing?path=%2F'..lua)
    execute('curl -s -k -L -m 2 -o /dev/null "http://'..ip..':8080/control/'..lenh..'_playing?path=%2F'..lua..'"')
end


function login()
        local startAt_login = {type=CONTROLLER_TYPE.INPUT, title="UID", key="startAt_login", value=ip}
        local lb_empty = {type=CONTROLLER_TYPE.LABEL, text=" "}
        local bt_all = {type=CONTROLLER_TYPE.BUTTON, title="Star TUONG_TAC_V2", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
        local bt_avarta = {type=CONTROLLER_TYPE.BUTTON, title="STOP TUONG_TAC_V2", color=0x4542f5, width=1.0, flag=2, collectInputs=true}
        local bt_all1 = {type=CONTROLLER_TYPE.BUTTON, title="Star UPDATE", color=0x4542f5, width=1.0, flag=3, collectInputs=true}
        local bt_4 = {type=CONTROLLER_TYPE.BUTTON, title="Star Respring", color=0x4542f5, width=1.0, flag=4, collectInputs=true}
        local bt_cancel = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0x4542f5, width=1.0, flag=6, collectInputs=true}
        local controls_login = {bt_all,bt_avarta,bt_all1, bt_4 , bt_cancel,startAt_login,lb_empty}
        local orientations_login = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
        result_dialog_login = dialog(controls_login, orientations_login);
        if (result_dialog_login == 1) then
        run("TUONG_TAC_V2.lua",1)
        elseif (result_dialog_login == 2) then
        run("TUONG_TAC_V2.lua",2)
        elseif (result_dialog_login == 3) then
        run("update.ate",1)
        elseif (result_dialog_login == 4) then
        run("respring.lua",1)
        end
end
login()