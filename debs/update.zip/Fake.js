const { exec, getSN, clipText, ocr, appActivate, appState, findImage, openURL, appRun, inputText, rootDir, usleep, toast, getColor, touchDown, touchUp, touchMove, keyDown, keyUp } = at;


const bundles = bundles = {
    tiktok = "com.ss.iphone.ugc.Ame",
    tiktoklite = "com.ss.iphone.ugc.tiktok.lite"
}
const listIOS = [
    '16.0', '16.0.1', '16.0.2', '16.0.3', '16.1', '16.1.1', '16.1.2', '16.2', '16.3', '16.3.1', '16.4.1', '16.5.1', '16.6.1', '16.4', '16.5', '16.6', '16.6.1', '16.7', '16.7.1', '16.7.2', '16.7.3', '16.7.4', '16.7.5', '16.7.6', '16.7.7', '16.7.8', '16.7.9', '16.7.10',
    '17.0', '17.0.1', '17.0.2', '17.0.3', '17.1', '17.1.1', '17.1.2', '17.2', '17.2.1', '17.3', '17.3.1', '17.4', '17.4.1', '17.5', '17.5.1', '17.6', '17.6.1', '17.7', '17.7.1', '17.7.2', '17.7.3'
]

const listDevices = [
    'iPhone 11', 'iPhone 11 Pro', 'iPhone 11 Pro Max', 'iPhone 12 mini', 'iPhone 12', 'iPhone 12 Pro', 'iPhone 12 Pro Max',
    'iPhone 13', 'iPhone 13 Pro', 'iPhone 13 Pro Max',
    'iPhone 14', 'iPhone 14 Pro', 'iPhone 14 Plus', 'iPhone 14 Pro Max', 'iPhone 15', 'iPhone 15 Plus', 'iPhone 15 Pro', 'iPhone 15 Pro Max',
]

function _ranbw(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
}

function _ClearandFake(bundleApp,bundleApp1) {
    let strVersion = listIOS[_ranbw(0, listIOS.length - 1)];
    let strModel = listDevices[_ranbw(0, listDevices.length - 1)];



    toast('Clearing data and Fake Devices', 'center', 3);
    exec('rm -rf /rootfs/var/mobile/Library/Safari/*')
    exec('rm -rf /rootfs/var/mobile/Library/WebKit/*')
    exec('rm -rf /rootfs/var/mobile/Library/Cookies/*')
    exec('rm -f  /rootfs/var/mobile/Library/Preferences/com.apple.mobilesafari.plist')

    exec("MUtil wipe com.apple.mobilesafari");
    exec("MUtil wipe_full com.apple.mobilesafari");

    //exec("MUtil wipe_full com.apple.mobilesafari");
    exec(`MUtil wipe ${bundleApp}`);
    exec(`MUtil wipe_full ${bundleApp}`);
	exec(`MUtil wipe ${bundleApp1}`);
    exec(`MUtil wipe_full ${bundleApp1}`);

    exec(`MUtil setConfig models '${strModel}'`);
    exec(`MUtil setConfig versions '${strVersion}'`);


    let x = exec(`MUtil fakeXoaInfo ${bundleApp} ${bundleApp1} com.apple.mobilesafari`);

    toast('Change Device Success', 'center', 2);
    usleep(2000000);
}



_ClearandFake(bundles.tiktok,bundles.tiktoklite);