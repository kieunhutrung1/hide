local lfs = require("lfs")
local curl = require("cURL")
local json = require("json")
local app = require("libs/support") 
local imgPath      = rootDir() .."/img/"
local Debug = rootDir() .."/Debug/*"
local bundleID     = "com.ss.iphone.ugc.Ame"
keepAutoTouchAwake(true);
appKill(bundleID);
keyPress(KEY_TYPE.HOME_BUTTON)
usleep(2000000)
keyPress(KEY_TYPE.HOME_BUTTON)
local ip = checkCountry()
function randomcfg(a,b,c)
    r =  random(b,c)
    return (tonumber(a) or 0) + r
end

dataconfig = split(licham365(613), "|")
countDay = tonumber(dataconfig[3])
counTimkiem = 0
counxemBinhLuan = 0
counrePost = 0
counxemLive = 0
counLike = 0
counSave = 0
randoocounTimkiem = randomcfg(tonumber(dataconfig[4]) ,1 , 3)
randoocounxemBinhLuan = randomcfg(tonumber(dataconfig[5]) ,1 , 3)
randoocounrePost =randomcfg(tonumber(dataconfig[6]) ,1 , 3)
randoocounxemLive = randomcfg(tonumber(dataconfig[7]) ,1 , 3)
randoocounLike = randomcfg(tonumber(dataconfig[8]) ,1 , 3)
randoocounSave = randomcfg(tonumber(dataconfig[9]) ,1 , 3)
TimeEnd1 = random(tonumber(dataconfig[1]) , tonumber(dataconfig[2]))

function autoTuongTac(countDay)
    countDay = countDay or 7
    local TimeEnd = TimeEnd1*60
    local Timeauto = os.time()
    local now = os.time()
    local futureTime = now + TimeEnd
    local formattedFuture = os.date("%H:%M:%S", futureTime)
    function thongbao()
        local diff = os.difftime(os.time(), TimeEnd)
        local minutes = math.floor(diff / 60)
            toast("Chạy tương tác tiktok ngày "..countDay..
            "\nIP: "..ip..
            "\nThời Gian chạy  "..TimeEnd1.." Phút" .. " Tắt lúc " ..formattedFuture..
            "\nTìm kiếm lần " .. counTimkiem .. "/" .. randoocounTimkiem ..
            "\nXem comment lần"..counxemBinhLuan.."/"..randoocounxemBinhLuan..
            "\nĐã like lần "..counLike.."/"..randoocounLike..
            "\nĐã Save lần "..counSave.."/"..randoocounSave..
            "\nGoto LIVE lần "..counxemLive.."/"..randoocounxemLive..
            "\nRepost video lần "..counrePost.."/"..randoocounrePost,3)
    end
    thongbao()
function login()
    openURL("snssdk1233://inbox")
    local startTime = os.time()
    while 1<2 do
        findimgsandclick({"img/bt_usernme.png"}, 1)
        if findimgsandclick({"img/bt_pass.png"}, 1) then
            copyText("Zxcv123123@")
            findimgsandclick({"img/bt_delete.png"}, 5)
            findimgsandclick({"img/bt_paste.png","img/bt_paste1.png"}, 5)
        end
        if findimgsandclick({"img/bt_continue.png"}, 1) then break end
        if os.difftime(os.time(), startTime) > 300 then
            stop();
        end
    end

end

    function reOpenTiktok()
        local orientation = frontMostAppOrientation();
        if orientation ~= bundleID then
            appRun(bundleID)
            usleep(15000000) 
        end
    end
    function check_Logout()
        if findimgs({"img/check_secure.png","img/check_loginform.png","img/check_login.png"},2) then
            toast("Logout",5)               
            stop();
        end
    end

    function timkiem()
        check_Logout()
        if counTimkiem < randoocounTimkiem then
            counTimkiem = counTimkiem + 1
            thongbao()
            openURL("snssdk1233://search")
            waitrandom(3,5)
            findimgsandclick({"img/xsearch.png","img/search.png"}, 2)
            waitrandom(3,5)
            findimgsandclick({"img/bt_data_search.png"}, 2)
            waitrandom(3,5)
            tap(169,327)
            waitrandom(3,5)
            for i = 1, 4 do
                local x=random(136,600)
                swipe(x,621, "up", 0.1,200)
                waitrandom(10,15)
            end
            reOpenTiktok()
            openURL("snssdk1233://inbox")
            usleep(6000000)        
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
            tap(65, 1280);
        else
            toast("Giới hạn Tìm kiếm"..randoocounTimkiem,2)
        end
    end
    function getRandomEmojis(n)
        math.randomseed(os.time()) -- Khởi tạo random
        local emojiList = {
            -- Cảm xúc khuôn mặt
            "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "🥲", "😊",
            "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙",
            "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎",
            "🥸", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁",
            "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠",
            "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥",
            -- Hành động & tay
            "👍", "👎", "👌", "✌️", "🤞", "🤟", "🤘", "🤙", "👊", "👏",
            "🙏", "👐", "🤲", "🤝", "🙌", "💪", "👋", "🤚", "✋", "🖐️",
            -- Biểu tượng trái tim
            "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💖",
            "💗", "💓", "💞", "💕", "❣️", "💔", "❤️‍🔥", "❤️‍🩹",
            -- Thiên nhiên & biểu tượng
            "🌞", "🌝", "🌚", "🌟", "✨", "🌈", "🔥", "💧", "❄️", "🌪️",
            "🎉", "🎊", "🎈", "💥", "💣", "🧨", "🕊️", "🌸", "🌼", "🌻"
        }

        local selected = {}
        local used = {}
        n = math.min(n, #emojiList)

        for i = 1, n do
            local index
            repeat
                index = math.random(1, #emojiList)
            until not used[index]
            table.insert(selected, emojiList[index])
            used[index] = true
        end

        return table.concat(selected, " ")
    end
    function xemBinhLuan()
        check_Logout()
        if counxemBinhLuan < randoocounxemBinhLuan then
            if findimgs({"img/check_video_running.png"},2) then
                counxemBinhLuan = counxemBinhLuan + 1
                thongbao()
                tap(707, 760,2);
                waitrandom(3,5) 
                for i = 1, 4 do
                    swipe(365, 621, "up", 0.2,150)
                    waitrandom(1,2)
                end
                local xxx = random(1, 5)
                if xxx ==1 then
                    local text = getRandomEmojis(random(1, 5))
                    copyText(text)
                    toast(text,3)
                    tap(315,1280)
                    wait(2)
                    if findimgsandclick({"img/bt_comment.png"}, 5) then
                        if findimgsandclick({"img/bt_paste.png","img/bt_paste1.png"},10) then findimgsandclick({"img/bt_send_comment.png"}, 5) end
                    end
                elseif xxx ==5 then findimgsandclick({"img/bt_like_comment.png"}, 5) end
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)        
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
                tap(65, 1280);
            else
                toast("Giới hạn Coment"..randoocounxemBinhLuan,2)
            end
        end
    end

    function saveVideo()
        check_Logout()
        if counSave < randoocounSave then
            if countDay > 6 then
                if findimgs({"img/check_video_running.png"},2) then
                    counSave = counSave + 1
                    thongbao()
                    tap(700,870)
                end
            end
        end
    end
    function clickLike()
    check_Logout()
        if counLike < randoocounLike then
            if countDay > 6 then
                if findimgs({"img/check_video_running.png"},2) then
                    counxemBinhLuan = counxemBinhLuan + 1
                    thongbao()
                    local t =random(1,2)
                    if t ==1 then
                    tap(707, 670)
                    else
                        local x=random(136,600)
                        local y=random(200,600)
                        local z=random(5,10)
                        tap(x,y,z)
                    end
                end
            end
        end
    end

    function luotvideo(time)
        local startTime = os.time()
        while 1<2 do
            check_Logout()
            local diff = os.difftime(os.time(), TimeEnd)
            local minutes = math.floor(diff / 60)
            toast("Chạy tương tác tiktok ngày "..countDay..
            "\nIP: "..ip..
            "\nThời Gian chạy  "..TimeEnd1.." Phút" .. " Tắt lúc " ..formattedFuture..
            "\nTìm kiếm lần " .. counTimkiem .. "/" .. randoocounTimkiem ..
            "\nXem comment lần"..counxemBinhLuan.."/"..randoocounxemBinhLuan..
            "\nĐã like lần "..counLike.."/"..randoocounLike..
            "\nĐã Save lần "..counSave.."/"..randoocounSave..
            "\nGoto LIVE lần "..counxemLive.."/"..randoocounxemLive..
            "\nRepost video lần "..counrePost.."/"..randoocounrePost..
            "\nLướt video "..os.difftime(os.time(), startTime).."/"..time.." Giây",3)
            local x=random(136,600)
            --swipe(x, 621, "up", 0.2,150)
            tap(65, 1280);
            waitrandom(8,15)
            if os.difftime(os.time(), startTime) > time then
                break
            end
        end
    end

    function xemLive()
            check_Logout()
        if counxemLive < randoocounxemLive then
            if findimgs({"img/check_video_running.png"},2) then
                counxemLive = counxemLive + 1
                thongbao()
                tap(72, 83);
                usleep(math.random(15000000, 20000000))
                if countDay < 7 then
                    swipe(365, 621, "up", 0.1,150)
                    usleep(math.random(30000000, 60000000))
                end
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)  
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
                tap(65, 1280);
            end   
        else
            toast("Giới hạn Goto LIVE"..randoocounxemLive,2)
        end
    end

    function rePost()
        if counrePost < randoocounrePost then
            check_Logout()
            if findimgs({"img/check_video_running.png"},2) then
                counrePost = counrePost + 1
                thongbao()
                tap(697, 1029);
                usleep(2300167.83);
                tap(74, 1025);
                usleep(3102982.83);
                tap(404, 1229);
                usleep(5102982.83);
                reOpenTiktok()
                openURL("snssdk1233://inbox")
                usleep(6000000)        
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
                tap(65, 1280);
            end   
        else
            toast("Giới hạn Goto LIVE "..randoocounrePost,2)
        end
    end

    reOpenTiktok()
    openURL("snssdk1233://inbox")
    usleep(6000000)
    check_Logout()
    local r_tuongtac = math.random(2, 4)
    if countDay < 7 then
        r_tuongtac = math.random(4, 5)
    end
    
    while 1<2 do
        reOpenTiktok()  
            check_Logout()
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)          
            if findimgs({"img/check_video_running.png"},2) then
                swipe(426,496, "up", 0.1,200)
            else
                local orientation = frontMostAppOrientation();
                if orientation ~= bundleID then
                    appRun(bundleID)
                    usleep(15000000) 
                end
                openURL("snssdk1233://inbox")
                findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
                usleep(500000)
                tap(65, 1280);
                usleep(500000)
                tap(65, 1280);
            end
            findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_not_now2.png","img/bt_open.png","img/bt_save.png","img/bt_wlan.png","img/bt_gotit.png"}, 2)
            luotvideo(random(60, 120))         
            local randoo = random(1, 7)
            toast("Lắc xí ngầu "..randoo,2)
            if randoo == 1 then
                usleep(2000000)
                toast("Bỏ Lượt",2)
            elseif randoo == 2 then
                clickLike()
            elseif randoo == 3 then
                xemBinhLuan()
            elseif randoo == 4 then
                clickLike()
                xemBinhLuan()
                xemLive()
            elseif randoo == 5 then
                rePost()
            elseif randoo == 6 then
                timkiem()
            elseif randoo == 7 then
                saveVideo()
            end
            wait(1)     
        if os.difftime(os.time(), Timeauto) > TimeEnd then
                break
        end
    end   
end

autoTuongTac(countDay)
appKill(bundleID);
closeAllApp()
execute("rm -r "..Debug)
