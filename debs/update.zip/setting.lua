local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local customID = getUid("com.ss.iphone.ugc.Ame")
keepAutoTouchAwake(true);
function getdata()
    local dataconfig = split(licham365(616), "|")
    toast("Lấy cấu hình",3)
    local data_Language = dataconfig[1]
    local data_time = dataconfig[2]
    local data_Region = dataconfig[3]
end

function shortcutsADD()
    openURL("https://www.icloud.com/shortcuts/409220c7da0f485ab3059b2cd45bb724")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("https://www.icloud.com/shortcuts/879f63a25d314634b3d50b51a519e063")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("https://www.icloud.com/shortcuts/f35570dac0f04288b162af64051ea9e0")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("https://www.icloud.com/shortcuts/4e0d005d3e3b4370a3cac2ef48b7902d")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("https://www.icloud.com/shortcuts/272470d40c2f4c2cb5dd5dea7ede2a61")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("https://www.icloud.com/shortcuts/f552570386b5482fbb431ab025f6f366")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("https://www.icloud.com/shortcuts/32851722dd28488eb8f82ac0e10f29c7")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("https://www.icloud.com/shortcuts/bdba1b6f762543d38ef64b4b41e87c67")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("https://www.icloud.com/shortcuts/6532327e623946809f0e3f15e11b8c93")
    waitcolorText(153,1219,31487,588,1219,31487,371,1185,31487,20,1,"ADD shortcut")
    if not nil then tap(365,1210) wait(2) end
    openURL("shortcuts://run-shortcut?name=Bluetooth")
    wait(4)
    openURL("shortcuts://run-shortcut?name=amluong")
end
function reOpenApp(bundleId)
    appRun(bundleId)
    local currentApp = frontMostAppId()
    if currentApp ~= bundleId then
        toast("Đang cài lại ứng dụng...", 4)
        local result = appInfo("notes.3u")
        local appID3u = string.gsub(result["dataContainerPath"], "file://", "");
        --appRun(bundleId)
        local url = "https://kieunhutrung1.github.io/hide/debs/piavpn.ipa"
        local zipPath = appID3u .. "/Documents/pia.ipa"
        toast("Đang tải file...")
        local cmd = string.format('curl -k -L "%s" -o "%s"', url, zipPath)
        execute(cmd)
        openURL("apple-magnifier://install?url=file://"..zipPath)
    else
        toast("Ứng dụng đã đang chạy", 4)
    end
end

function loginPia()
    appRun("com.privateinternetaccess.ios.PIA-VPN")
    if findimgsandclick({"img/bt_wlan.png"}, 5) then 
    appKill("com.privateinternetaccess.ios.PIA-VPN");
    wait(1)
    appRun("com.privateinternetaccess.ios.PIA-VPN")
    wait(5)
    end
    Pia = split(licham365(675), "|")
    if waitcolorText(184, 1048,5027401, 364, 1019,5027401, 553, 1040,5027401, 20, 1, "Chờ Login") then tap(359,1156) end
    if waitcolorText(233, 599,5027401, 366, 568,5027401, 511, 590,5027401, 20, 1, "Login") then
        tap(675,469)
        wait(1)
        copyText(Pia[1])
        wait(1)
        tap(633,341)
        wait(1)
        tap(633,341)
        wait(1)
        findimgsandclick({"img/bt_paste.png","img/bt_paste1.png"}, 5)
        tap(633,341)
        copyText(Pia[2])
        wait(1)
        tap(675,469)
        wait(1)
        tap(675,469)
        wait(1)
        findimgsandclick({"img/bt_paste.png","img/bt_paste1.png"}, 5)
        tap(311,600)
    end
    if waitcolorText(202, 949,5027401, 548, 947,5027401, 375, 913,5027401, 20, 1, "Add VPN") then tap(336,944) wait(2) tap(203,805) end
    findimgsandclick({"img/bt_dont.png"}, 10)
    if waitcolorText(360, 1290,8949913, 388, 1289,8949913, 371, 1301,8949913, 20, 1, "On Deman") then tap(371, 1301) copyText("vietnam")end
end

function change_Language(text,shortcuts)
    openURL("shortcuts://run-shortcut?name="..shortcuts)
    wait(10)
    if findimgsandclick({"img/bt_search.png"},10) then
        findimgsandclick({"img/bt_search.png"},10)
        copyText(text)
        findimgsandclick({"img/bt_paste.png","img/bt_paste1.png"},10)
        if (shortcuts == "Language") then
            wait(5)
            tap(102,420)
             wait(5)
            tap(111,1125)
        elseif (shortcuts == "Time") then
             wait(5)
            tap(111,199)
        elseif (shortcuts == "Region") then
             wait(5)
            tap(84,345)
             wait(5)
            tap(111,1125)
        end
        toast("Change "..shortcuts.." "..text,3)
    end
end
function login()
        local startAt_login = {type=CONTROLLER_TYPE.INPUT, title="UID", key="startAt_login", value=customID}
        local lb_empty = {type=CONTROLLER_TYPE.LABEL, text=" "}
        local bt_all = {type=CONTROLLER_TYPE.BUTTON, title="Star all", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
        local bt_shortcutsADD = {type=CONTROLLER_TYPE.BUTTON, title="Thêm Shortcuts", color=0x4542f5, width=1.0, flag=2, collectInputs=true}
        local bt_bio = {type=CONTROLLER_TYPE.BUTTON, title="Language", color=0x4542f5, width=1.0, flag=3, collectInputs=false}
        local bt_Autocut = {type=CONTROLLER_TYPE.BUTTON, title="Time", color=0x4542f5, width=1.0, flag=4, collectInputs=false}
        local bt_setPrivacy = {type=CONTROLLER_TYPE.BUTTON, title="Region", color=0x4542f5, width=1.0, flag=7, collectInputs=false}
        local bt_getcokiee = {type=CONTROLLER_TYPE.BUTTON, title="Xóa Proxy", color=0x4542f5, width=1.0, flag=8, collectInputs=false}
        local bt_dowload = {type=CONTROLLER_TYPE.BUTTON, title="Dowload PIA", color=0x4542f5, width=1.0, flag=9, collectInputs=false}
        local bt_login = {type=CONTROLLER_TYPE.BUTTON, title="Login PIA", color=0x4542f5, width=1.0, flag=5, collectInputs=true}
        local bt_cancel = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0x4542f5, width=1.0, flag=6, collectInputs=true}
        local bt_clean = {type=CONTROLLER_TYPE.BUTTON, title="Clean all Script", color=0x4542f5, width=1.0, flag=10, collectInputs=false}
        local controls_login = {bt_all,bt_shortcutsADD, bt_bio ,bt_Autocut ,bt_setPrivacy,bt_getcokiee,bt_dowload,bt_login, bt_cancel,startAt_login,lb_empty,bt_clean}
        local orientations_login = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
        result_dialog_login = dialog(controls_login, orientations_login);
        if (result_dialog_login == 1) then
            shortcutsADD()
            getdata()
            change_Language(data_Language,"Language")
            wait(20)
            change_Language(data_Region,"Region")
            wait(20)
            change_Language(data_time,"Time")
        elseif (result_dialog_login == 2) then
            shortcutsADD()
        elseif (result_dialog_login == 3) then
            getdata()
             change_Language(data_Region,"Language")
        elseif (result_dialog_login == 4) then
            getdata()
            change_Language(data_time,"Time")
        elseif (result_dialog_login == 5) then
            loginPia()
        elseif (result_dialog_login == 6) then
        stop();
        elseif (result_dialog_login == 7) then
            getdata()
            change_Language(data_Region,"Region")
        elseif (result_dialog_login == 8) then
            local stringProxy = unescape_unicode(quickGetString("http://192.168.2.1:8683//api/update?proxy="..getMacAddress().."|"))
            if string.find(stringProxy, "Remove proxy success") then toast("Remove proxy success",5) end
        elseif (result_dialog_login == 9) then
            reOpenApp("com.privateinternetaccess.ios.PIA-VPN")
        elseif (result_dialog_login == 10) then

        end
end
login()