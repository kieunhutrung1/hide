local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local customID = getUid("com.ss.iphone.ugc.Ame")
keepAutoTouchAwake(true);

local dataconfig = split(licham365(616), "|")
local data_Region = dataconfig[1]
local data_time = dataconfig[1]
function shortcutsADD()
    openURL("https://www.icloud.com/shortcuts/409220c7da0f485ab3059b2cd45bb724")
    wait(10)
    tap(365,1210)
    openURL("https://www.icloud.com/shortcuts/879f63a25d314634b3d50b51a519e063")
    wait(10)
    tap(365,1210)
    openURL("https://www.icloud.com/shortcuts/f35570dac0f04288b162af64051ea9e0")
    wait(10)
    tap(365,1210)
    openURL("https://www.icloud.com/shortcuts/4e0d005d3e3b4370a3cac2ef48b7902d")
    wait(10)
    tap(365,1210)
    openURL("https://www.icloud.com/shortcuts/272470d40c2f4c2cb5dd5dea7ede2a61")
    wait(10)
    tap(365,1210)
    openURL("shortcuts://run-shortcut?name=Bluetooth")
end

function change_Language(text,shortcuts)
    openURL("shortcuts://run-shortcut?name="..shortcuts)
    wait(10)
    if findimgsandclick({"img/bt_search.png"},10) then
        findimgsandclick({"img/bt_search.png"},10)
        copyText(text)
        findimgsandclick({"img/bt_paste.png","img/bt_paste1.png"},10)
        if (shortcuts == "Language") then
            wait(5)
            tap(102,420)
             wait(5)
            tap(111,1125)
        elseif (shortcuts == "Time") then
             wait(5)
            tap(111,199)
        elseif (shortcuts == "Region") then
             wait(5)
            tap(84,345)
             wait(5)
            tap(111,1125)
        end
        toast("Change "..shortcuts.." "..text,3)
    end
end
function login()
        local startAt_login = {type=CONTROLLER_TYPE.INPUT, title="UID", key="startAt_login", value=customID}
        local lb_empty = {type=CONTROLLER_TYPE.LABEL, text=" "}
        local bt_all = {type=CONTROLLER_TYPE.BUTTON, title="Star all", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
        local bt_shortcutsADD = {type=CONTROLLER_TYPE.BUTTON, title="Thêm Shortcuts", color=0x4542f5, width=1.0, flag=2, collectInputs=true}
        local bt_bio = {type=CONTROLLER_TYPE.BUTTON, title="Language", color=0x4542f5, width=1.0, flag=3, collectInputs=false}
        local bt_Autocut = {type=CONTROLLER_TYPE.BUTTON, title="Time", color=0x4542f5, width=1.0, flag=4, collectInputs=false}
        local bt_setPrivacy = {type=CONTROLLER_TYPE.BUTTON, title="Region", color=0x4542f5, width=1.0, flag=7, collectInputs=false}
        local bt_getcokiee = {type=CONTROLLER_TYPE.BUTTON, title="Lấy Cokiee", color=0x4542f5, width=1.0, flag=8, collectInputs=false}
        local bt_dowload = {type=CONTROLLER_TYPE.BUTTON, title="Dowload JPG", color=0x4542f5, width=1.0, flag=9, collectInputs=false}
        local bt_login = {type=CONTROLLER_TYPE.BUTTON, title="Delete Photo", color=0x4542f5, width=1.0, flag=5, collectInputs=true}
        local bt_cancel = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0x4542f5, width=1.0, flag=6, collectInputs=true}
        local bt_clean = {type=CONTROLLER_TYPE.BUTTON, title="Clean all Script", color=0x4542f5, width=1.0, flag=10, collectInputs=false}
        local controls_login = {bt_all,bt_shortcutsADD, bt_bio ,bt_Autocut ,bt_setPrivacy,bt_getcokiee,bt_dowload, bt_cancel, bt_login,startAt_login,lb_empty,bt_clean}
        local orientations_login = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
        result_dialog_login = dialog(controls_login, orientations_login);
        if (result_dialog_login == 1) then
            shortcutsADD()
            wait(5)
            change_Language(data_Region,"Language")
            wait(5)
            change_Language(data_time,"Time")
            wait(5)
            change_Language(data_Region,"Region")    
        elseif (result_dialog_login == 2) then
            shortcutsADD()
        elseif (result_dialog_login == 3) then
             change_Language(data_Region,"Language")
        elseif (result_dialog_login == 4) then
            change_Language(data_time,"Time")
        elseif (result_dialog_login == 5) then
            
        elseif (result_dialog_login == 6) then
        stop();
        elseif (result_dialog_login == 7) then
            change_Language(data_Region,"Region")
        elseif (result_dialog_login == 8) then
       
        elseif (result_dialog_login == 9) then
 
        elseif (result_dialog_login == 10) then

        end
end
login()