local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local customID = getUid("com.ss.iphone.ugc.Ame")

function setPrivacy()
    openURL("snssdk1233://setting")
    usleep(2000000)
    if findimgsandclick({"img/bt_privacy_select.png"},10) then
        usleep(2000000)
        swipe(200,1500,200,300,0.3)
        usleep(2000000)
        if findimgsandclick({"img/bt_privacy_following.png"},3) then
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(2000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
        if findimgsandclick({"img/bt_privacy_liked.png"},3) then
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(2000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
    end
end
function upAvata()
    openURL("https://picsum.photos/400")
    usleep(3000000)
    findimgs({"img/check_loadimg.png"},15)
    usleep(5000000)
    touchDown(5, 383.87, 113.46);
    usleep(965873.71);
    touchUp(5, 383.87, 113.46);
    findimgsandclick({"img/bt_save_img.png","img/bt_saveimg.png"},5,0.98)
    usleep(1000000)
        appKill("com.apple.mobilesafari")
    usleep(5000000)
    openURL("snssdk1233://user/profile/"..customID)
    usleep(5000000)
    if findimgsandclick({"img/bt_editprofile.png","img/bt_editprofile2.png","img/bt_editprofile3.png"},5) then
        usleep(2033684.42);
        if not findimgsandclick({"img/bt_changephoto.png"},10,0.98) then
            tap(379.76, 357.80);
            usleep(1033684.42);
        end
        if findimgsandclick({"img/bt_uploadphoto.png"},5,0.98) then
            usleep(3033684.42);
            touchDown(5, 97.50, 235.63);
            usleep(150255.58);
            touchUp(5, 97.50, 235.63);
            usleep(1650136.62);
            findimgsandclick({"img/bt_poststory.png"},3)
            local startTime = os.time()
            while 1<2 do
                findimgsandclick({"img/bt_saveavata.png"},2)  
                if os.difftime(os.time(), startTime) > 20 then
                    break
                end						
            end      
        end           
    end		
    openURL("snssdk1233://setting")
    usleep(4000000)
    if findimgsandclick({"img/bt_privacy_select.png"},10) then
        usleep(3000000)
        swipe(426,496,475,165,0.1)
        usleep(1000000)
        swipe(426,496,475,165,0.1)
        usleep(3000000)
        if findimgsandclick({"img/bt_privacy_following.png"},3) then
            usleep(1000000)
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(1000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
        if findimgsandclick({"img/bt_privacy_liked.png"},3) then
            usleep(1000000)
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(1000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
    end		
    
end
function addBio()
function getRandomEmojis(n)
math.randomseed(os.time()) -- Khởi tạo random
    local emojiList = {
        -- Cảm xúc khuôn mặt
        "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "🥲", "😊",
        "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙",
        "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎",
        "🥸", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁",
        "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠",
        "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥",
        -- Hành động & tay
        "👍", "👎", "👌", "✌️", "🤞", "🤟", "🤘", "🤙", "👊", "👏",
        "🙏", "👐", "🤲", "🤝", "🙌", "💪", "👋", "🤚", "✋", "🖐️",
        -- Biểu tượng trái tim
        "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💖",
        "💗", "💓", "💞", "💕", "❣️", "💔", "❤️‍🔥", "❤️‍🩹",
        -- Thiên nhiên & biểu tượng
        "🌞", "🌝", "🌚", "🌟", "✨", "🌈", "🔥", "💧", "❄️", "🌪️",
        "🎉", "🎊", "🎈", "💥", "💣", "🧨", "🕊️", "🌸", "🌼", "🌻"
    }

    local selected = {}
    local used = {}
    n = math.min(n, #emojiList)

    for i = 1, n do
        local index
        repeat
            index = math.random(1, #emojiList)
        until not used[index]
        table.insert(selected, emojiList[index])
        used[index] = true
    end

    return table.concat(selected, " ")
end
  toast("Mở Profile",3)
  openURL("snssdk1233://user/profile/"..customID)
    if findimgsandclick({"img/bt_bio.png"},10) then
      local text = licham365(614) .. getRandomEmojis(math.random(1, 4))
      toast(text,3)
      copyText(text)
      usleep(1000000)
      tap(100,180)
      usleep(1000000)
      if findimgsandclick({"img/bt_paste.png"},10) then
          usleep(1000000)
          tap(674,86)
      end
    else
    toast("Không thấy nút add Bio",3)
    end
end
function Autocut_post()
toast("Mở Profile",3)
openURL("snssdk1233://user/profile/"..customID)
wait(3-5)
  if findimgsandclick({"img/bt_upload.png"},10) then
      tap(211,261)
      wait(3-5)
      if findimgsandclick({"img/bt_autocut.png"},10) then
          wait(15,20)
          if findimgsandclick({"img/bt_next.png"},10) then
                wait(3-5)
                      if findimgsandclick({"img/bt_post.png"},10) then
                      end
          end
      end
  end
end
function deletephoto()
usleep(2000000)
    appKill("com.apple.mobileslideshow");
    usleep(1317023.21);
    openURL("photos-navigation://")
    findimgsandclick({"img/bt_dont.png","img/bt_ask.png","img/bt_not_now.png","img/bt_not_now1.png","img/bt_open.png","img/bt_save.png"}, 10)
    usleep(5317023.21);    
    tap(462.90, 1280.24);
    usleep(1317023.21);
    tap(218.62, 484.07);
    usleep(1317023.21);
    tap(694.86, 84.94);
    usleep(1317023.21);
    tap(651.76, 432.14);
    usleep(1665450.33);
    tap(531.67, 733.50);
    usleep(684721.54);
    tap(680.50, 134.83);
    usleep(2083711.71);
    tap(606.59, 81.89);
    usleep(2083711.88);
    tap(148.82, 381.23);
    usleep(150918.62);
    tap(369.50, 373.07);
    usleep(166742.29);
    tap(602.50, 352.72);
    usleep(300263.79);
    tap(119.05, 587.90);
    usleep(151402.17);
    tap(352.05, 601.15);
    usleep(167910.12);
    tap(615.83, 592.99);
    usleep(268241.96);
    tap(125.21, 841.42);
    usleep(168130.04);
    tap(393.10, 867.89);
    usleep(184907.33);
    tap(613.78, 820.05);
    usleep(2083711.29);
    tap(692.81, 1290.42);
    usleep(2083711.29);    
    tap(542.96, 1131.59);
    usleep(1083711.29);
    tap(556.31, 1135.66);
    usleep(3083711.29);
end
function login()
        local startAt_login = {type=CONTROLLER_TYPE.INPUT, title="UID", key="startAt_login", value=customID}
        local lb_empty = {type=CONTROLLER_TYPE.LABEL, text=" "}
        local bt_all = {type=CONTROLLER_TYPE.BUTTON, title="Star all", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
        local bt_avarta = {type=CONTROLLER_TYPE.BUTTON, title="Up Avarta", color=0x4542f5, width=1.0, flag=2, collectInputs=true}
        local bt_bio = {type=CONTROLLER_TYPE.BUTTON, title="ADD Bio", color=0x4542f5, width=1.0, flag=3, collectInputs=false}
        local bt_Autocut = {type=CONTROLLER_TYPE.BUTTON, title="AutoCut", color=0x4542f5, width=1.0, flag=4, collectInputs=false}
        local bt_login = {type=CONTROLLER_TYPE.BUTTON, title="Delete Photo", color=0x4542f5, width=1.0, flag=5, collectInputs=true}
        local bt_cancel = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0x4542f5, width=1.0, flag=6, collectInputs=true}
        local controls_login = {bt_all,bt_avarta, bt_bio ,bt_Autocut , bt_cancel,startAt_login, bt_login,lb_empty}
        local orientations_login = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
        result_dialog_login = dialog(controls_login, orientations_login);
        if (result_dialog_login == 1) then
        upAvata()
        elseif (result_dialog_login == 2) then
        upAvata()
        elseif (result_dialog_login == 3) then
        addBio()
        elseif (result_dialog_login == 4) then
        Autocut_post()
        elseif (result_dialog_login == 5) then
        deletephoto()
        elseif (result_dialog_login == 6) then
        stop();
        end
end
login()
--upAvata()
--addBio()
--Autocut_post()
--deletephoto()