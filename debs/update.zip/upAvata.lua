local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local customID = getUid("com.ss.iphone.ugc.Ame")
keepAutoTouchAwake(true);
function setPrivacy()
    openURL("snssdk1233://setting")
    usleep(4000000)
    if findimgsandclick({"img/bt_privacy_select.png"},10) then
        usleep(3000000)
        swipe(426,496,475,165,0.1)
        usleep(1000000)
        swipe(426,496,475,165,0.1)
        usleep(3000000)
        if findimgsandclick({"img/bt_privacy_following.png"},3) then
            usleep(1000000)
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(1000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
        if findimgsandclick({"img/bt_privacy_liked.png"},3) then
            usleep(1000000)
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(1000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
    end
end

function dowload_jpg()
    openURL("https://picsum.photos/400")
    usleep(3000000)
    findimgs({"img/check_loadimg.png"},15)
    usleep(5000000)
    touchDown(5, 383.87, 113.46);
    usleep(965873.71);
    touchUp(5, 383.87, 113.46);
    findimgsandclick({"img/bt_save_img.png","img/bt_saveimg.png"},5,0.98)
    usleep(1000000)
    appKill("com.apple.mobilesafari")
    usleep(1000000)
    toast("Lấy Ảnh Xong",3)
end

function upAvata()
    openURL("snssdk1233://user/profile/"..customID)
    usleep(5000000)
    if findimgsandclick({"img/bt_editprofile.png","img/bt_editprofile2.png","img/bt_editprofile3.png"},5) then
        usleep(2033684.42);
        if not findimgsandclick({"img/bt_changephoto.png"},10,0.98) then
            tap(379.76, 357.80);
            usleep(1033684.42);
        end
        if findimgsandclick({"img/bt_uploadphoto.png"},5,0.98) then
            usleep(3033684.42);
            touchDown(5, 97.50, 235.63);
            usleep(150255.58);
            touchUp(5, 97.50, 235.63);
            usleep(1650136.62);
            findimgsandclick({"img/bt_poststory.png"},3)
            local startTime = os.time()
            while 1<2 do
                findimgsandclick({"img/bt_saveavata.png"},2)  
                if os.difftime(os.time(), startTime) > 20 then
                    break
                end						
            end      
        end           
    end		
end
function cookieTT()
    local resultTiktokInfo = appInfo("com.ss.iphone.ugc.Ame")
    local basePath = string.gsub(resultTiktokInfo["dataContainerPath"], "file://", "")
    local cookiePath = basePath .. "/Library/Cookies/Cookies.binarycookies"
    local file = io.open(cookiePath, "rb")
    if not file then
        toast("❌ Không tìm thấy file Cookies.binarycookies: " .. cookiePath, 5)
        return
    end
    local data = file:read("*all")
    file:close()
    local pos = string.find(data, "sessionid")
    if not pos then
        toast("❌ Không tìm thấy sessionid", 5)
        return
    end
    local tail = string.sub(data, pos + 9, pos + 100)
    local session_value = findBinaryValue(data, "sessionid")
    if not session_value then
        session_value = findBinaryValue(data, "sessionid_ss")
    end
    local keys = {
        "odin_tt", "store-idc", "store-country-code", "store-country-code-src", "store-country-sign",
        "passport_csrf_token", "passport_csrf_token_default", "tt-target-idc", "tt-target-idc-sign",
        "multi_sids", "sid_guard", "uid_tt", "uid_tt_ss", "sid_tt",
        "sessionid_ss", "msToken"
    }
    local result = { ["sessionid"] = session_value }
    for _, key in ipairs(keys) do
        local val = findBinaryValue(data, key)
        if val then
            result[key] = val
        end
    end
    local parts = {}
    for k, v in pairs(result) do
        table.insert(parts, k .. "=" .. urlEncode(v))
    end
    local resultString = table.concat(parts, "; ")
    local resultString = urlEncode(resultString)
    local stringAPI = unescape_unicode(quickGetString("https://script.google.com/macros/s/AKfycbz3l9qX0AFPmGBIsaziaMOsPLyBKAzydpsNbOS0rbbfk3cpQWR9DysThw9IT8v5mEtj/exec?sheet=COKIEE&SN="..getSN().."&UID="..customID.."&Token="..resultString))
    if string.find(stringAPI, "success") then
    toast("Lưu vào dòng : "..tonumber(string.match(stringAPI, '"row"%s*:%s*(%d+)')), 5)
    end
end
function addBio()
function getRandomEmojis(n)
math.randomseed(os.time()) -- Khởi tạo random
    local emojiList = {
        -- Cảm xúc khuôn mặt
        "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "🥲", "😊",
        "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙",
        "😚", "😋", "😛", "😝", "😜", "🤪", "🤨", "🧐", "🤓", "😎",
        "🥸", "🤩", "🥳", "😏", "😒", "😞", "😔", "😟", "😕", "🙁",
        "☹️", "😣", "😖", "😫", "😩", "🥺", "😢", "😭", "😤", "😠",
        "😡", "🤬", "🤯", "😳", "🥵", "🥶", "😱", "😨", "😰", "😥",
        -- Hành động & tay
        "👍", "👎", "👌", "✌️", "🤞", "🤟", "🤘", "🤙", "👊", "👏",
        "🙏", "👐", "🤲", "🤝", "🙌", "💪", "👋", "🤚", "✋", "🖐️",
        -- Biểu tượng trái tim
        "❤️", "🧡", "💛", "💚", "💙", "💜", "🖤", "🤍", "🤎", "💖",
        "💗", "💓", "💞", "💕", "❣️", "💔", "❤️‍🔥", "❤️‍🩹",
        -- Thiên nhiên & biểu tượng
        "🌞", "🌝", "🌚", "🌟", "✨", "🌈", "🔥", "💧", "❄️", "🌪️",
        "🎉", "🎊", "🎈", "💥", "💣", "🧨", "🕊️", "🌸", "🌼", "🌻"
    }

    local selected = {}
    local used = {}
    n = math.min(n, #emojiList)

    for i = 1, n do
        local index
        repeat
            index = math.random(1, #emojiList)
        until not used[index]
        table.insert(selected, emojiList[index])
        used[index] = true
    end

    return table.concat(selected, " ")
end
  toast("Mở Profile",3)
  openURL("snssdk1233://user/profile/"..customID)
  local text = licham365(614) .. getRandomEmojis(math.random(1, 4))
      toast(text,3)
      copyText(text)
    wait(5,6)
    if findimgsandclick({"img/bt_bio.png","img/bt_bio1.png","img/bt_bio2.png"},10) then
      wait(1,2)
      tap(100,180)
      usleep(1000000)
      if findimgsandclick({"img/bt_paste.png","img/bt_paste1.png"},10) then
          usleep(1000000)
          tap(674,86)
      end
    else
    toast("Không thấy nút add Bio",3)
    end
end
function Autocut_post()
toast("Mở Profile",3)
openURL("snssdk1233://user/profile/"..customID)
wait(3-5)
  if findimgsandclick({"img/bt_upload.png"},10) then
    wait(3-5)
      tap(211,261)
      wait(3-5)
      if findimgsandclick({"img/bt_autocut.png"},10) then
          wait(15,20)
          if findimgsandclick({"img/bt_next.png"},10) then
                wait(3-5)
                findimgsandclick({"img/bt_post.png"},10)
          end
      end
  end
end
function deletephoto()
usleep(2000000)
clearSystemAlbum();
toast("Xóa all ảnh",3)
end
function login()
        local startAt_login = {type=CONTROLLER_TYPE.INPUT, title="UID", key="startAt_login", value=customID}
        local lb_empty = {type=CONTROLLER_TYPE.LABEL, text=" "}
        local bt_all = {type=CONTROLLER_TYPE.BUTTON, title="Star all", color=0x4542f5, width=1.0, flag=1, collectInputs=true}
        local bt_avarta = {type=CONTROLLER_TYPE.BUTTON, title="Up Avarta", color=0x4542f5, width=1.0, flag=2, collectInputs=true}
        local bt_bio = {type=CONTROLLER_TYPE.BUTTON, title="ADD Bio", color=0x4542f5, width=1.0, flag=3, collectInputs=false}
        local bt_Autocut = {type=CONTROLLER_TYPE.BUTTON, title="AutoCut", color=0x4542f5, width=1.0, flag=4, collectInputs=false}
        local bt_setPrivacy = {type=CONTROLLER_TYPE.BUTTON, title="SetPrivacy", color=0x4542f5, width=1.0, flag=7, collectInputs=false}
        local bt_getcokiee = {type=CONTROLLER_TYPE.BUTTON, title="Lấy Cokiee", color=0x4542f5, width=1.0, flag=8, collectInputs=false}
        local bt_dowload = {type=CONTROLLER_TYPE.BUTTON, title="Dowload JPG", color=0x4542f5, width=1.0, flag=9, collectInputs=false}
        local bt_login = {type=CONTROLLER_TYPE.BUTTON, title="Delete Photo", color=0x4542f5, width=1.0, flag=5, collectInputs=true}
        local bt_cancel = {type=CONTROLLER_TYPE.BUTTON, title="STOP", color=0x4542f5, width=1.0, flag=6, collectInputs=true}
        local bt_clean = {type=CONTROLLER_TYPE.BUTTON, title="Clean all Script", color=0x4542f5, width=1.0, flag=10, collectInputs=false}
        local controls_login = {bt_all,bt_avarta, bt_bio ,bt_Autocut ,bt_setPrivacy,bt_getcokiee,bt_dowload, bt_cancel, bt_login,startAt_login,lb_empty,bt_clean}
        local orientations_login = { ORIENTATION_TYPE.PORTRAIT, ORIENTATION_TYPE.LANDSCAPE_LEFT, ORIENTATION_TYPE.LANDSCAPE_RIGHT };
        result_dialog_login = dialog(controls_login, orientations_login);
        if (result_dialog_login == 1) then
        dowload_jpg()
        upAvata()
        setPrivacy()
        addBio()
        Autocut_post()
        deletephoto()
        elseif (result_dialog_login == 2) then
        dowload_jpg()
        upAvata()
        elseif (result_dialog_login == 3) then
        addBio()
        elseif (result_dialog_login == 4) then
        Autocut_post()
        elseif (result_dialog_login == 5) then
        deletephoto()
        elseif (result_dialog_login == 6) then
        stop();
        elseif (result_dialog_login == 7) then
        setPrivacy()
        elseif (result_dialog_login == 8) then
        cookieTT()
        elseif (result_dialog_login == 9) then
        dowload_jpg()
        elseif (result_dialog_login == 10) then
        execute("rm -r "..rootDir().."/*")
        end
end
login()
