local app = require("libs/support") 
local lfs = require("lfs")
local imgPath = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID = "com.ss.iphone.ugc.Ame"
local customID = getUid("com.ss.iphone.ugc.Ame")



function setPrivacy()
    openURL("snssdk1233://setting")
    usleep(2000000)
    if findimgsandclick({"img/bt_privacy_select.png"},10) then
        usleep(2000000)
        swipe(200,1500,200,300,0.3)
        usleep(2000000)
        if findimgsandclick({"img/bt_privacy_following.png"},3) then
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(2000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
        if findimgsandclick({"img/bt_privacy_liked.png"},3) then
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(2000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
    end
end
function upAvata()
    openURL("https://music9.online/getimg.php")
    usleep(3000000)
    findimgs({"img/check_loadimg.png"},15)
    usleep(5000000)
    touchDown(5, 383.87, 113.46);
    usleep(965873.71);
    touchUp(5, 383.87, 113.46);
    findimgsandclick({"img/bt_save_img.png","img/bt_saveimg.png"},5,0.98)
    usleep(1000000)
    appRun(bundleID)
    usleep(20000000)
    openURL("snssdk1233://user/profile/"..customID)
    usleep(5000000)
    if findimgsandclick({"img/bt_editprofile.png","img/bt_editprofile2.png","img/bt_editprofile3.png"},5) then
        usleep(2033684.42);
        if not findimgsandclick({"img/bt_changephoto.png"},10,0.98) then
            tap(379.76, 357.80);
            usleep(1033684.42);
        end
        if findimgsandclick({"img/bt_uploadphoto.png"},5,0.98) then
            usleep(3033684.42);
            touchDown(5, 97.50, 235.63);
            usleep(150255.58);
            touchUp(5, 97.50, 235.63);
            usleep(1650136.62);
            findimgsandclick({"img/bt_poststory.png"},3)
            local startTime = os.time()
            while 1<2 do
                findimgsandclick({"img/bt_saveavata.png"},2)  
                if os.difftime(os.time(), startTime) > 20 then
                    break
                end						
            end      
        end           
    end		
    openURL("snssdk1233://setting")
    usleep(4000000)
    if findimgsandclick({"img/bt_privacy_select.png"},10) then
        usleep(3000000)
        swipe(426,496,475,165,0.1)
        usleep(1000000)
        swipe(426,496,475,165,0.1)
        usleep(3000000)
        if findimgsandclick({"img/bt_privacy_following.png"},3) then
            usleep(1000000)
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(1000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
        if findimgsandclick({"img/bt_privacy_liked.png"},3) then
            usleep(1000000)
            if findimgsandclick({"img/bt_privacy_everyone.png"},3) then
                usleep(1000000)
                findimgsandclick({"img/bt_privacy_close.png"},3)
            end
        end
    end		
    usleep(2000000)
    appKill("com.apple.mobileslideshow");
    usleep(1317023.21);
    openURL("photos-navigation://")
    usleep(5317023.21);    
    tap(462.90, 1280.24);
    usleep(1317023.21);
    tap(218.62, 484.07);
    usleep(1317023.21);
    tap(694.86, 84.94);
    usleep(1317023.21);
    tap(651.76, 432.14);
    usleep(1665450.33);
    tap(531.67, 733.50);
    usleep(684721.54);
    tap(680.50, 134.83);
    usleep(2083711.71);
    tap(606.59, 81.89);
    usleep(2083711.88);
    tap(148.82, 381.23);
    usleep(150918.62);
    tap(369.50, 373.07);
    usleep(166742.29);
    tap(602.50, 352.72);
    usleep(300263.79);
    tap(119.05, 587.90);
    usleep(151402.17);
    tap(352.05, 601.15);
    usleep(167910.12);
    tap(615.83, 592.99);
    usleep(268241.96);
    tap(125.21, 841.42);
    usleep(168130.04);
    tap(393.10, 867.89);
    usleep(184907.33);
    tap(613.78, 820.05);
    usleep(2083711.29);
    tap(692.81, 1290.42);
    usleep(2083711.29);    
    tap(542.96, 1131.59);
    usleep(1083711.29);
    tap(556.31, 1135.66);
    usleep(3083711.29);
end
upAvata()