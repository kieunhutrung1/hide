local app = require("libs/support")
function licham3651(stt)
local stringAPI = unescape_unicode(quickGetString("https://licham365.com/clone/users/"..stt.."/check"))
    if string.find(stringAPI, "success") then
        local data = string.match(stringAPI, '"data"%s*:%s*"(.*)"')
        data = data:gsub('\\"', '"'):gsub("\\n", "\n")
        return data
    else
        local message = string.match(stringAPI, '"data"%s*:%s*"([^"]+)"')
        return message ,nil or "Lỗi không xác định"
    end
end
local token = licham3651(677)
execute("rm -r "..rootDir() .. "/xxx.lua")
wait(1)
filewrite(rootDir() .. "/xxx.lua", token)
wait(1)
execute('curl -s -k -L  "http://127.0.0.1:8080/control/start_playing?path=%2Fxxx.lua"')