function respring()
    execute("sbreload")
end
respring()