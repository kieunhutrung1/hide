local lfs = require("lfs")
local curl = require("cURL")
local json = require("json")
local app = require("libs/support") 
local imgPath      = rootDir() .."/img/"
local usernameFile = rootDir() .. "/username.txt"
local Debug = rootDir() .."/Debug/*"
local bundleID     = "com.ss.iphone.ugc.Ame"
function reOpenTiktok()
    local orientation = frontMostAppOrientation();
    if orientation ~= bundleID then
        appRun(bundleID)
        usleep(6000000) 
    end
end
local access_token = licham365(615)
local customID = getUid("com.ss.iphone.ugc.Ame")
toast("ID: "..customID..
      "\nToken: "..access_token,2)
function tdsRun(countDay,time)
if countDay > 6 then

                if access_token ~= nil and access_token ~= "Không có từ khóa nào" and access_token ~= "" then
                    appRun("com.ss.iphone.ugc.Ame")
                    usleep(5000000)
                    --https://traodoisub.com/api/?fields=tiktok_run&id={{idTiktok}}&access_token={{TDS_token}}
                    --https://traodoisub.com/api/?fields=tiktok_run&id=trung.kieu862&access_token=TDS0nI1IXZ2V2ciojIyVmdlNnIsISNwAjMpxWZ0F2YiojIyV2c1Jye
                    local stringAPI = unescape_unicode(quickGetString("https://traodoisub.com/api/api2.php?fields=tiktok_add&id="..customID.."&access_token="..access_token))
                    --local stringAPI = unescape_unicode(quickGetString("https://traodoisub.com/api/?fields=tiktok_run&id="..customID.."&access_token="..access_token))
                    
                    usleep(10000000)
                    if string.find(stringAPI, "Cấu hình thành công") then
                        toast("Cấu hình thành công",3)
                        local countNhiemvu = 1;
                        local follow_ok = 0;
                        local follow_er = 0;
                        local follow_er_max = 3;
                        for i = 1, time do
                            shouldBreak = 0
                            for i = 1, 2 do
                                local stringAPINhiemVu = ""
                                while 1<2 do
                                    stringAPINhiemVu = unescape_unicode(quickGetString("https://traodoisub.com/api/api2.php?fields=tiktok_follow&access_token="..access_token))
                                    toast("NV: "..stringAPINhiemVu,2)
                                    usleep(10000000)
                                    if string.find(stringAPINhiemVu, "countdown") then
                                        local countdown = tonumber(string.match(stringAPINhiemVu, '"countdown"%s*:%s*(%d+)'))
                                        usleep(countdown*1000000)
                                        usleep(5000000)
                                    else
                                        break;
                                    end
                                end
                                for id, uid in string.gmatch(stringAPINhiemVu, '"id"%s*:%s*"([^"]+)"%s*,%s*"real_id"%s*:%s*"[^"]+"%s*,%s*"link"%s*:%s*"[^"]+"%s*,%s*"uniqueID"%s*:%s*"([^"]+)"') do
                                     function thongbao()
                                    toast("Chạy tương tác tiktok ngày "..countDay..
                                    "\nID: "..customID..
                                    "\nFollow User: "..uid..
                                    "\nJod: "..follow_ok.."/"..countNhiemvu..
                                    "\nJod Lỗi: "..follow_er.."/"..follow_er_max,3)
                                    end
                                    thongbao()                                    
                                    local stringAPINhanNhiemVu = unescape_unicode(quickGetString("https://traodoisub.com/api/coin/?type=TIKTOK_FOLLOW_CACHE&id="..id.."&access_token="..access_token))
                                    usleep(10000000)
                                    if string.find(stringAPINhanNhiemVu, "Thành công") then
                                        errTDS = 0
                                        countNhiemvu = countNhiemvu + 1
                                        thongbao()
                                        openURL("snssdk1233://user/@"..uid)
                                        waitrandom(3,5)
                                        findimgsandclick({"img/follow_button.png","img/follow_button1.png"}, 2)
                                        waitrandom(3,5)
                                        openURL("snssdk1233://user/@"..uid)
                                        waitrandom(3,5)
                                        local check = waitImage("img/follow_check.png", 10)
                                        if (check ~= false) then
                                            follow_ok = follow_ok +1;
                                           thongbao()
                                            shouldBreak = 1
                                        else
                                        follow_er = follow_er +1;
                                        thongbao()
                                        if (follow_er > follow_er_max) then
                                        shouldBreak = -1
                                        break
                                        end
                                        end
                                    else
                                        toast("Lỗi nhận nhiệm vụ",2)
                                        usleep(2000000)
                                        errTDS = errTDS + 1
                                        if errTDS > 5 then
                                            toast("5 lần liên tiếp không nhận được nv",5)
                                            shouldBreak = -1                                
                                            break
                                        end
                                    end                            
                                end
                                if shouldBreak < 0 then break end
                            end
                            usleep(5000000)
                            local stringAPINhanXu = unescape_unicode(quickGetString("https://traodoisub.com/api/coin/?type=TIKTOK_FOLLOW&id=TIKTOK_FOLLOW_API&access_token="..access_token))
                            usleep(10000000)
                            if string.find(stringAPINhanXu, "error") then
                                local error_msg = string.match(stringAPINhanXu, '"error"%s*:%s*"([^"]+)"')
                                toast(error_msg or "Không tìm thấy error", 5)
                            else                        
                                local msg = string.match(stringAPINhanXu, '"msg"%s*:%s*"([^"]+)"')
                                toast(msg or "Lỗi không xác định", 10)
                            end
                            if shouldBreak < 0 then break end
                        end
                    else
                        toast("Lỗi cấu hình"..customID,2)
                        local error_msg = string.match(stringAPI, '"error"%s*:%s*"([^"]+)"')
                        toast(error_msg or "Không tìm thấy error", 5)
                    end
                end  
            end
 end  
tdsRun(7,2)
execute("rm -r "..Debug)