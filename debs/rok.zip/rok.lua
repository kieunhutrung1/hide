local app = require("libs/support")
local Debug = rootDir() .. "/Debug/*"

-- ======== HÀM XỬ LÝ HOME ========
function home()
    if not waitcolorText(159, 708, 16777215, 166, 702, 16777215, 135, 704, 16777215, 2, 1, "") then  
        tap(63, 680) 
        wait(1) 
    end
    touchDown(4, 63, 680)
    wait(1)
    touchUp(4, 63, 680)
    wait(2)
    tap(268, 584)
end

-- ======== HÀM SWIPE THEO HƯỚNG ========
function swipeByDirection(direction)
    if direction == "up" then
        swipe(629, 621, "up", 0.2, 500)
    elseif direction == "down" then
        swipe(655, 72, "down", 0.2, 630)
    elseif direction == "right" then
        swipe(124, 401, "right", 0.4, 900)
    elseif direction == "left" then
        swipe(1186, 361, "left", 0.4, 920)
    else
        print("⚠️ Hướng không hợp lệ:", direction)
    end
end

-- ======== ƯU TIÊN XỬ LÝ BACK TOÀN BỘ ĐỘI (MỚI: DỪNG XOẮN ỐC NGAY) ========
function checkBackAll(stopIfFound)
    local backDetected = false
    local slots = {
        f1 = {coords = {1292, 224, 1298, 219, 1305, 224}, tapY = 219, backColor = {11820288, 11885824, 11820288}},
        f2 = {coords = {1292, 304, 1298, 299, 1305, 304}, tapY = 299, backColor = {11820288, 11885824, 11820288}},
        f3 = {coords = {1292, 384, 1298, 379, 1305, 384}, tapY = 379, backColor = {11820288, 11885824, 11820288}},
        f4 = {coords = {1292, 464, 1298, 459, 1305, 464}, tapY = 459, backColor = {11820288, 11885824, 11820288}},
        f5 = {coords = {1292, 543, 1298, 539, 1295, 540}, tapY = 539, backColor = {11820544, 11885824, 11885825}}
    }

    for name, slot in pairs(slots) do
        local c = getColorText(slot.coords)
        if c and #c >= 3 then
            local bc = slot.backColor
            if c[1] == bc[1] and c[2] == bc[2] and c[3] == bc[3] then
                toast("Đội " .. name .. " đang BACK", 2)
                tap(63, 680) wait(1) tap(1298, slot.tapY)
                findimgsandclick({"img/rok_dung.png"}, 10)
                backDetected = true
                if stopIfFound then return true end
            end
        end
    end
    return backDetected
end

-- ======== TÌM GEM THEO XOẮN ỐC ========
function framgem(xxx)
    local steps = 1
    local totalSwipes = 0
    local maxSwipes = 25
    local directions = {"right", "down", "left", "up"}
    local dirIndex = 1

    home()

    while totalSwipes < maxSwipes do
        for repeatTwice = 1, 2 do
            for i = 1, steps do
                if totalSwipes >= maxSwipes then return end
                if checkBackAll(false) then
                    toast("Dừng xoắn ốc do phát hiện BACK", 2)
                    return
                end

                if findimgsandclick({"img/rok_lv3_gem.png", "img/rok_lv3_gem1.png", "img/rok_lv3_gem2.png","img/rok_lv3_gem3.png", "img/rok_lv3_gem4.png", "img/rok_lv3_gem5.png", "img/rok_lv3_gem6.png", "img/rok_lv3_gem7.png"}, 10, 0.97) then
                    wait(1)
                    if findimgsandclick({"img/rok_gemok.png", "img/rok_gemok1.png", "img/rok_gemok2.png", "img/rok_gemok3.png", "img/rok_gemok4.png"}, 5, 0.94) then
                        thuthap(xxx)
                        return
                    end
                    home()
                    wait(2)
                else
                    toast("Không tìm thấy", 2)
                end

                swipeByDirection(directions[dirIndex])
                totalSwipes = totalSwipes + 1
            end
            dirIndex = (dirIndex % 4) + 1
        end
        steps = steps + 1
    end
end

-- ======== LẤY MÀU THEO TOẠ ĐỘ ========
function getColorText(flatCoords)
    local coords = {}
    for i = 1, #flatCoords, 2 do
        table.insert(coords, {flatCoords[i], flatCoords[i + 1]})
    end
    return getColors(coords)
end

-- ======== KIỂM TRA TRẠNG THÁI MỖI ĐỘI (TRỪ BACK) ========
function checkSlot(slotName, coords, tapY)
    local c = getColorText(coords)
    if not c or #c < 3 then
        return "Không xác định"
    end

    if c[1] == 36546 and c[2] == 36546 and c[3] == 36546 then
        tap(63, 680) wait(1) tap(1298, tapY)
        framgem(slotName)
        return "stop"
    elseif c[1] == 956928 and c[2] == 956928 and c[3] == 956928 then
        return "farm"
    else
        return "Không xác định"
    end
end

-- ======== HÀM THU THẬP ========
function thuthap(fram)
    local framCoords = {
        f1 = {1265, 105},
        f2 = {1265, 230},
        f3 = {1265, 355},
        f4 = {1265, 475},
        f5 = {1265, 600}
    }

    local pos = framCoords[fram]
    if not pos then
        toast("⚠️ Không tìm thấy toạ độ cho: " .. tostring(fram), 3)
        return
    end

    local x, y = pos[1], pos[2]

    if findimgsandclick({"img/rok_thuthap.png"}, 5) then
        if findimgsandclick({"img/rok_quanmoi.png"}, 5) then
            wait(1)
            tap(1150, 270)
            wait(1)
            tap(1150, 325)
            wait(1)
            tap(1150, 385)
            wait(1)
            tap(1150, 440)
            wait(1)
            tap(1150, 500)
            wait(1)
            tap(978, 660)
        else
            wait(1)
            tap(x, y)
            wait(math.random(2, 3))
            findimgsandclick({"img/rok_hanhquan.png"}, 10)
        end
    end
end

-- ======== VÒNG LẶP CHÍNH ========
function check_farm()
    while true do
        findimgsandclick({"img/rok_xacnhan.png","img/rok_exitchat.png"}, 2)
        if checkBackAll(false) then
            toast("Đang xử lý các đội BACK...", 2)
            wait(5)
        else
            local f1 = checkSlot("f1", {1292, 224, 1298, 219, 1305, 224}, 219)
            local f2 = checkSlot("f2", {1292, 304, 1298, 299, 1305, 304}, 299)
            local f3 = checkSlot("f3", {1292, 384, 1298, 379, 1305, 384}, 379)
            local f4 = checkSlot("f4", {1292, 464, 1298, 459, 1305, 464}, 459)
            local f5 = checkSlot("f5", {1292, 543, 1298, 539, 1295, 540}, 539)

            toast("Đội F1: "..f1..
                  "\nĐội F2: "..f2..
                  "\nĐội F3: "..f3..
                  "\nĐội F4: "..f4..
                  "\nĐội F5: "..f5, 3)

            if f1 == "farm" and f2 == "farm" and f3 == "farm" and f4 == "farm" and f5 == "farm" then
                toast("Tất cả đang farm. Nghỉ 20 giây...", 3)
                wait(20)
            elseif f1 == "Không xác định" or f2 == "Không xác định" or f3 == "Không xác định" or f4 == "Không xác định" or f5 == "Không xác định" then
                toast("Phát hiện trạng thái không xác định. Reset map", 2)
                tap(63, 680)
                wait(2)
            else
                wait(5)
            end
        end
    end
end

-- ======== BẮT ĐẦU ========
check_farm()